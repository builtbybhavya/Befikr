# NIRIKSHAK - Windows PowerShell Development Launcher
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host " Starting NIRIKSHAK - Delhi Crime Intel & Route Platform  " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

# 1. Start Backend in background or separate window
Write-Host "[1/2] Starting FastAPI Backend on http://127.0.0.1:8000..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload"

# 2. Start Frontend in background or separate window
Write-Host "[2/2] Starting Vite React Frontend on http://localhost:5173..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd frontend; npm run dev"

Write-Host "NIRIKSHAK is running!" -ForegroundColor Yellow
Write-Host "Frontend: http://localhost:5173" -ForegroundColor White
Write-Host "Backend API & Docs: http://127.0.0.1:8000/docs" -ForegroundColor White
