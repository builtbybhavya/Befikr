@echo off
echo ==========================================================
echo  Starting NIRIKSHAK - Delhi Crime Intel & Route Platform
echo ==========================================================

start "NIRIKSHAK Backend" cmd /k "python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload"
start "NIRIKSHAK Frontend" cmd /k "cd frontend && npm run dev"

echo NIRIKSHAK servers launched in separate windows!
echo Frontend: http://localhost:5173
echo Backend API Docs: http://127.0.0.1:8000/docs
