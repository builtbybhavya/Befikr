#!/usr/bin/env python3
"""
NIRIKSHAK — End-to-End Automated Smoke Test
Validates health, sources, incidents, routing, explainable scoring, and review queue.
"""

import sys
import os
import json

# Ensure project root is in sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi.testclient import TestClient
from backend.app.main import app
from backend.app.db.session import SessionLocal
from backend.app.db.init_db import init_database


def run_smoke_test():
    print("=" * 70)
    print("NIRIKSHAK — End-to-End Smoke Test Execution")
    print("=" * 70)

    # 1. Initialize Database
    db = SessionLocal()
    init_database(db)
    db.close()
    print("[1/7] Database initialized and seeded with Delhi gazetteer & demo data.")

    client = TestClient(app)

    # 2. System Health Check
    res = client.get("/api/health")
    assert res.status_code == 200, f"Health check failed: {res.text}"
    health = res.json()
    print(f"[2/7] Health Check OK: {health['app_name']} v{health['version']} (Env: {health['environment']})")

    # 3. Source Registry
    res = client.get("/api/sources")
    assert res.status_code == 200
    sources = res.json()
    assert len(sources) >= 5, "Fewer than 5 sources found"
    print(f"[3/7] Sources Registry OK: {len(sources)} registered Delhi sources found.")

    # 4. Incident Explorer & Filters
    res = client.get("/api/incidents?limit=50")
    assert res.status_code == 200
    inc_data = res.json()
    assert inc_data["total"] > 0
    print(f"[4/7] Incidents Retrieval OK: {inc_data['total']} incidents available across Delhi.")

    # 5. Route Analysis (Rohini Sector 10 to Connaught Place)
    payload = {
        "origin": {"lat": 28.7118, "lon": 77.1154, "name": "Rohini Sector 10"},
        "destination": {"lat": 28.6315, "lon": 77.2167, "name": "Connaught Place"},
        "travel_mode": "driving",
        "departure_time": "19:00",
        "departure_day": "Friday",
        "use_osrm": False
    }
    res = client.post("/api/routes/analyze", json=payload)
    assert res.status_code == 200, f"Route analysis failed: {res.text}"
    route_data = res.json()
    assert len(route_data["alternatives"]) >= 2
    alt1 = route_data["alternatives"][0]
    alt2 = route_data["alternatives"][1]
    print(f"[5/7] Route Analysis OK: Compared 2 corridors:")
    print(f"      - '{alt1['route_name']}': Score {alt1['overall_risk_score']}/100, {alt1['incident_count']} incidents, {round(alt1['total_distance_m']/1000, 1)} km")
    print(f"      - '{alt2['route_name']}': Score {alt2['overall_risk_score']}/100, {alt2['incident_count']} incidents, {round(alt2['total_distance_m']/1000, 1)} km")
    print(f"      - Insight: {route_data['comparison_summary']}")

    # 6. Verification Review Queue Action
    test_inc_id = inc_data["incidents"][0]["internal_id"]
    res = client.post(f"/api/incidents/{test_inc_id}/verify", json={
        "status": "verified",
        "notes": "Verified by automated smoke test suite",
        "performed_by": "qa_engineer"
    })
    assert res.status_code == 200
    print(f"[6/7] Review Queue Action OK: Verified incident {test_inc_id}.")

    # 7. Analytics & Diagnostic Overview
    res = client.get("/api/analytics/overview")
    assert res.status_code == 200
    analytics = res.json()
    print(f"[7/7] Analytics & Coverage OK: {analytics['data_coverage_percentage']}% NCT districts covered.")
    print("=" * 70)
    print("ALL 7 END-TO-END SMOKE TESTS PASSED CLEANLY.")
    print("=" * 70)


if __name__ == "__main__":
    run_smoke_test()
