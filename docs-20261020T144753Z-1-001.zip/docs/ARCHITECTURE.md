# NIRIKSHAK System Architecture

**Project:** NIRIKSHAK — Delhi Crime Intelligence & Route Risk Platform  
**Architecture Style:** Modular Monolith with Decoupled Services

---

## 1. System Context Diagram

```
+-----------------------------------------------------------------------------------+
|                                  USER / CLIENT                                    |
|                      (Web Browser, Desktop, Mobile Web)                           |
+----------------------------------------+------------------------------------------+
                                         | HTTP / JSON REST
                                         v
+-----------------------------------------------------------------------------------+
|                        FRONTEND (React 18 + Vite + Tailwind)                      |
|                                                                                   |
|  [Header & SOS]   [Crime Map Leaflet]   [Safer Routes View]   [Incident Explorer] |
|  [Source Intel]   [Analytics Charts]    [Settings Sliders]    [Emergency Modal]   |
+----------------------------------------+------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
|                             BACKEND (FastAPI Modular App)                         |
|                                                                                   |
|  +-----------------------------------------------------------------------------+  |
|  | API Routing Layer (/api/health, /api/sources, /api/incidents, /api/routes)  |  |
|  +-----------------------------------------------------------------------------+  |
|                                                                                   |
|  +-------------------------+  +-------------------------+  +-------------------+  |
|  | Ingestion Engine        |  | NLP & Gazetteer Engine  |  | Routing & Risk    |  |
|  | - RSS Feed Ingester     |  | - Heuristic / LLM Rules |  | - OSRM Router     |  |
|  | - PDF & Document Parser |  | - Delhi Locality Catalog|  | - 150m Segmenter  |  |
|  | - User Upload Registry  |  | - Spatial Deduplicator  |  | - 5-Factor Scorer |  |
|  +-------------------------+  +-------------------------+  +-------------------+  |
|                                                                                   |
|  +-----------------------------------------------------------------------------+  |
|  | Data Layer: SQLAlchemy 2.0 ORM (SQLite / PostgreSQL with PostGIS support)   |  |
|  +-----------------------------------------------------------------------------+  |
+----------------------------------------+------------------------------------------+
                                         |
            +----------------------------+----------------------------+
            v                                                         v
+-----------------------+                                 +-----------------------+
|  Local SQLite DB      |                                 | External Integrations |
|  (nirikshak.db)       |                                 | - OSRM Public API     |
|  - Sources & Docs     |                                 | - Delhi Open Data     |
|  - Incidents (Live)   |                                 | - News RSS Feeds      |
|  - Synthetic Fixtures |                                 | - Google Maps (Opt.)  |
+-----------------------+                                 +-----------------------+
```

---

## 2. Directory Layout

```
PathMaster/ (nirikshak)
├── backend/
│   ├── app/
│   │   ├── api/            # FastAPI Endpoint Routers
│   │   │   ├── health.py
│   │   │   ├── sources.py
│   │   │   ├── ingestion.py
│   │   │   ├── incidents.py
│   │   │   ├── areas.py
│   │   │   ├── analytics.py
│   │   │   ├── routes.py
│   │   │   └── settings.py
│   │   ├── core/           # Configuration & Settings
│   │   ├── db/             # Engine, Sessions, Migrations & Seeders
│   │   ├── models/         # SQLAlchemy 2.0 ORM Entities
│   │   ├── schemas/        # Pydantic Schemas & Request/Response Models
│   │   └── services/       # Core Business Logic Engines
│   │       ├── ingestion/  # RSS & File Ingestion
│   │       ├── extraction/ # NLP Extraction & Deduplication
│   │       ├── geocoding/  # Delhi Gazetteer & Coordinates
│   │       ├── routing/    # OSRM & Delhi Hub Router
│   │       ├── risk/       # 5-Factor Explainable Scoring
│   │       └── analytics/  # Metric Aggregation
│   └── tests/              # Pytest Unit & Integration Tests
├── frontend/
│   ├── src/
│   │   ├── components/     # Reusable UI (MapComponent, Header, EmergencyModal)
│   │   ├── pages/          # 7 Core Views (Overview, Map, Routes, Explorer, etc.)
│   │   ├── services/       # Axios API Client
│   │   └── types/          # TypeScript Domain Interfaces
│   └── vitest.config.ts    # Vitest Runner Config
├── data/fixtures/          # Synthetic Delhi Demo Data Fixtures
├── scripts/                # Development Launchers & Smoke Tests
├── docs/                   # Full Technical Documentation
├── docker-compose.yml      # PostGIS Production Deployment
├── .env.example            # Environment Variable Specification
└── README.md               # Main Project Documentation
```

---

## 3. Database Entity Relationship Model

- **Source (1) ── (N) SourceDocument:** Stores incoming raw articles and PDF uploads.
- **Source (1) ── (N) Incident:** Connects extracted incidents to publisher provenance.
- **Incident (1) ── (N) VerificationEvent:** Immutable audit log for corrections and review queue actions.
- **RouteAnalysis (1) ── (N) RouteAlternative:** Stores comparative evaluation between origins and destinations.
- **RouteAlternative (1) ── (N) RouteSegment:** 150m spatial units with local infrastructure indicators.
- **RouteSegment (N) ── (M) Incident:** Correlates incidents within 250m corridor buffer.
