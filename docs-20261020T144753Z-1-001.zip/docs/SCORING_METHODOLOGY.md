# NIRIKSHAK Route Risk Scoring Methodology

**Document Version:** 1.0.0  
**Coverage:** National Capital Territory (NCT) of Delhi, India

---

## 1. Core Engineering Principle

The NIRIKSHAK scoring engine computes a **comparative, evidence-adjusted relative risk estimate** between alternative travel corridors. 

> [!IMPORTANT]
> The score (0 to 100) is **not a calibrated probability of physical harm** and must never be interpreted as an objective guarantee that any route is completely "safe" or "dangerous". It evaluates relative crime exposure and infrastructural vulnerability based on recorded public data.

---

## 2. 5-Component Mathematical Model

The composite route risk score $S_{\text{route}} \in [0, 100]$ is computed as a weighted sum of five normalized dimensions:

$$S_{\text{route}} = w_{\text{exp}} \cdot C_{\text{exp}} + w_{\text{rec}} \cdot C_{\text{rec}} + w_{\text{inf}} \cdot C_{\text{inf}} + w_{\text{tod}} \cdot C_{\text{tod}} + w_{\text{unc}} \cdot C_{\text{unc}}$$

Where the default engineered weights sum to $1.0$:

| Dimension | Symbol | Default Weight | Objective |
| :--- | :--- | :--- | :--- |
| **Crime Exposure** | $C_{\text{exp}}$ | **40%** ($w_{\text{exp}} = 0.40$) | Spatial density of crime incidents along corridor segments |
| **Incident Recency** | $C_{\text{rec}}$ | **20%** ($w_{\text{rec}} = 0.20$) | Age-weighted decay prioritizing recent incidents |
| **Contextual Infrastructure**| $C_{\text{inf}}$ | **15%** ($w_{\text{inf}} = 0.15$) | Street lighting, police stations, transit hubs, and road class |
| **Time-of-Day Pattern** | $C_{\text{tod}}$ | **15%** ($w_{\text{tod}} = 0.15$) | Correlation between departure time and historical vulnerability |
| **Data Uncertainty** | $C_{\text{unc}}$ | **10%** ($w_{\text{unc}} = 0.10$) | Explicit penalty for data sparsity / missing report gaps |

---

## 3. Spatial Segmentation & Corridor Buffers

1. **Uniform Spatial Units:**  
   Every candidate route is segmented into uniform spatial units of length $\Delta L \approx 150 \text{ meters}$.
2. **Buffer Radius ($R_{\text{buf}}$):**  
   For each segment midpoint $P_{\text{seg}} = (\text{lat}_{\text{seg}}, \text{lon}_{\text{seg}})$, an incident $I_k$ with coordinates $(\text{lat}_k, \text{lon}_k)$ is associated if:
   $$d_{\text{haversine}}(P_{\text{seg}}, I_k) \le R_{\text{buf}} = 250 \text{ meters}$$
3. **Spatial Distance Decay Factor:**
   $$f_{\text{dist}}(d) = 1.0 - \left(\frac{d}{R_{\text{buf}}}\right) \cdot 0.5$$
   *(Incidents directly on the corridor contribute $1.0$; incidents at the 250m perimeter contribute $0.5$)*.

---

## 4. Dimension Calculations

### A. Crime Exposure ($C_{\text{exp}}$)
For each segment $j$:
$$\text{Impact}_j = \sum_{k \in \text{Incidents}} \text{SeverityWeight}(\text{Category}_k) \cdot \text{StatusWeight}(\text{Status}_k) \cdot f_{\text{dist}}(d_{jk}) \cdot \text{RecencyDecay}_k \cdot \text{TimeFactor}_k$$

- **Category Multipliers:**
  - Homicide: $4.0$
  - Sexual Offences: $4.0$
  - Kidnapping & Abduction: $3.5$
  - Assault & Grievous Hurt: $3.0$
  - Robbery & Snatching: $2.0$
  - Vehicle Theft: $1.5$
  - Burglary: $1.5$
  - Public Order / Rioting: $1.5$
  - Financial Fraud / Other: $1.0$

- **Status Weight:**
  - Court confirmed: $1.0$
  - Police reported / FIR registered: $0.90$
  - Reported allegation: $0.70$
  - Unverified source: $0.60$

### B. Exponential Recency Decay ($C_{\text{rec}}$)
Recency follows an exponential half-life decay model:
$$\text{RecencyDecay}(t) = \exp\left(-\ln(2) \cdot \frac{\text{age\_days}}{T_{\text{half}}}\right)$$
- Default half-life $T_{\text{half}} = 180 \text{ days}$ (6 months).
- An incident from today contributes $1.0$; an incident from 6 months ago contributes $0.5$; an incident from 1 year ago contributes $0.25$.

### C. Contextual Infrastructure Indicator ($C_{\text{inf}}$)
Evaluates physical street-level environment proxies:
- **Adequate Street Lighting:** $-10$ points risk reduction.
- **Poor / Broken Street Lighting:** $+15$ points risk increase.
- **Police Station within 1km:** $-15$ points risk reduction.
- **Active Metro / Transit Station within 500m:** $-5$ points risk reduction (constant CCTV and pedestrian footfall).

### D. Time-of-Day ($C_{\text{tod}}$)
Departure hours are mapped to historical temporal risk bands:
- Late Night (00:00 - 05:00): Score $65 - 95$
- Night (21:00 - 24:00): Score $55 - 75$
- Evening (17:00 - 21:00): Score $40 - 50$
- Morning & Afternoon (08:00 - 17:00): Score $25 - 35$

### E. Data Uncertainty Penalty ($C_{\text{unc}}$)
> [!CAUTION]
> A critical safeguard: In regions where public news or police reports are sparse, NIRIKSHAK applies a high uncertainty score ($60 - 90$) and flags the analysis with **"Low Confidence"** or **"Insufficient Data"**, ensuring missing reporting is never falsely portrayed as low crime.

---

## 5. Score Normalization & Output

- Final score is bounded to $[0.0, 100.0]$.
- Displayed with:
  - Exact component bar breakdown.
  - Plain-English explanations.
  - Confidence rating ("High", "Moderate", "Low", "Insufficient Data").
  - Immutable link to original source publications.
