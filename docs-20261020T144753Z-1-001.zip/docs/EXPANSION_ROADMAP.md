# NIRIKSHAK National Expansion Roadmap

**Initial Scope:** National Capital Territory of Delhi, India  
**Target Horizon:** Pan-India Urban Safety Intelligence

---

## Phase 1: National Capital Region (NCR Expansion)
- Expand geographic gazetteer and police subdivision boundaries to neighboring NCR districts:
  - **Gurugram & Faridabad** (Haryana)
  - **Noida & Greater Noida** (Gautam Buddha Nagar, Uttar Pradesh)
  - **Ghaziabad** (Uttar Pradesh)
- Ingest Haryana Police and UP Police public notices and district press releases.

---

## Phase 2: Major Tier-1 Metros
1. **Mumbai Metropolitan Region (MMR):**
   - Ingest Mumbai Police daily bulletins and local transport corridors (Western Railway, Central Railway, BEST bus hubs).
   - Marathi-language news feed extraction adapter.
2. **Bengaluru Urban:**
   - Ingest Karnataka Police datasets, Outer Ring Road IT corridors, and BMTC/Namma Metro transit buffers.
   - Kannada-language NLP models.
3. **Hyderabad, Kolkata & Chennai:**
   - Cyberabad police data integrations, Kolkata municipal wards, and Greater Chennai Police records.

---

## Phase 3: Technical Scalability & Nationwide Architecture
- **Database Partitioning:** PostgreSQL / PostGIS range and hash partitioning by State and Police Zone.
- **Multilingual Semantic Embeddings:** Lightweight IndicBERT / Multilingual E5 models for local language headline deduplication.
- **Citizen Verification Network:** Trusted community review network with cryptographically signed verification tokens.
