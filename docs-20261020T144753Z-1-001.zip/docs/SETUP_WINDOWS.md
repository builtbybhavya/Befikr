# Windows 11 Local Setup & Execution Guide

This document provides step-by-step instructions for installing, configuring, running, and testing **NIRIKSHAK** locally on a Windows 11 machine without requiring Docker or paid API keys.

---

## 1. Prerequisites

- **Python**: 3.11+ ([Download python.org](https://www.python.org/downloads/)) - *Ensure "Add Python to PATH" is checked during installation*.
- **Node.js**: v20+ or v22+ ([Download nodejs.org](https://nodejs.org/))
- **Git**: 2.40+ ([Download git-scm.com](https://git-scm.com/))

Verify prerequisites in PowerShell:
```powershell
python --version
node --version
npm --version
git --version
```

---

## 2. Environment Configuration

1. Clone or navigate to the repository directory:
   ```powershell
   cd "C:\Users\<YourUsername>\Desktop\VS Code\PathMaster"
   ```

2. Copy `.env.example` to `.env`:
   ```powershell
   Copy-Item .env.example .env
   ```

3. Default `.env` settings are already pre-configured for offline local development:
   - `APP_ENV=development`
   - `DEMO_MODE=true` (Uses verified synthetic Delhi demo fixtures)
   - `DATABASE_URL=sqlite:///./nirikshak.db` (Self-bootstrapping local SQLite database)
   - `OSRM_ROUTER_URL=https://router.project-osrm.org` (OpenStreetMap routing engine)
   - Google Maps keys can remain empty. OpenStreetMap/Leaflet fallback is active by default.

---

## 3. Backend Setup & Dependencies

Install the required Python backend packages:
```powershell
python -m pip install -r backend/requirements.txt
```
*(Or install core dependencies manually: `python -m pip install fastapi uvicorn sqlalchemy alembic shapely beautifulsoup4 feedparser pydantic-settings python-dotenv pymupdf pytest httpx`)*

---

## 4. Frontend Setup & Dependencies

Navigate to the `frontend` directory and install npm packages:
```powershell
cd frontend
npm install
cd ..
```

---

## 5. Running the Application

You can launch both frontend and backend using our automated launcher:
```powershell
.\scripts\start_dev.ps1
```
*(Or use `.\scripts\start_dev.bat` from Command Prompt)*

Alternatively, launch them in two separate PowerShell terminal tabs:

**Terminal 1 (Backend API):**
```powershell
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
```
- API Base URL: `http://127.0.0.1:8000`
- Interactive Swagger API Docs: `http://127.0.0.1:8000/docs`
- Health Diagnostic: `http://127.0.0.1:8000/api/health`

**Terminal 2 (Frontend React App):**
```powershell
cd frontend
npm run dev
```
- Frontend UI: `http://localhost:5173`

---

## 6. Running Automated Tests

Run backend pytest suite:
```powershell
python -m pytest backend/tests -v
```

Run frontend vitest suite:
```powershell
cd frontend
npx vitest run
cd ..
```

Run full end-to-end integration smoke test:
```powershell
python scripts/smoke_test.py
```
