# NIRIKSHAK REST API Specification

**Base URL:** `http://127.0.0.1:8000/api`  
**Interactive Docs:** `http://127.0.0.1:8000/docs`  
**OpenAPI JSON:** `http://127.0.0.1:8000/openapi.json`

---

## 1. System Health

### `GET /api/health`
Returns system status, active integrations, and demo mode indicator.

**Response:**
```json
{
  "status": "operational",
  "app_name": "NIRIKSHAK",
  "version": "1.0.0",
  "environment": "development",
  "demo_mode": true,
  "database_connected": true,
  "google_maps_configured": false,
  "osrm_router_url": "https://router.project-osrm.org",
  "llm_provider": "mock"
}
```

---

## 2. Crime Sources & Ingestion

### `GET /api/sources`
Retrieves registered public crime reporting sources and reliability scores.

### `POST /api/sources/{source_id}/sync`
Triggers immediate live ingestion and parsing for a registered source.

### `POST /api/ingestion/upload`
Uploads a public report file (`multipart/form-data`) in PDF, CSV, JSON, or TXT format.

**Form Data:**
- `file`: Document binary
- `publisher`: Name of publishing authority
- `source_type`: `official` | `news` | `user_upload`

---

## 3. Incidents & Review Queue

### `GET /api/incidents`
Retrieves paginated, filtered crime records across Delhi NCT.

**Query Parameters:**
- `category` (string, optional)
- `severity` (string, optional): `low` | `medium` | `high` | `critical`
- `verification_status` (string, optional): `verified` | `unverified` | `disputed` | `rejected`
- `locality` (string, optional)
- `is_synthetic` (boolean, optional)
- `search` (string, optional)
- `limit` (integer, default 100)
- `offset` (integer, default 0)

### `GET /api/incidents/{incident_id}`
Returns detailed incident record with source passage and coordinates.

### `POST /api/incidents/{incident_id}/verify`
Human-in-the-loop review queue action.
```json
{
  "status": "verified",
  "notes": "Verified against police press release",
  "performed_by": "analyst_name"
}
```

### `POST /api/incidents/{incident_id}/correct`
Corrects incident category, locality, or coordinates with audit trail.

---

## 4. Routes & Risk Analysis

### `POST /api/routes/analyze`
Generates candidate routes between Delhi coordinates, segments geometry into 150m units, associates corridor incidents, and evaluates 5-factor risk scores.

**Request Payload:**
```json
{
  "origin": {
    "lat": 28.7118,
    "lon": 77.1154,
    "name": "Rohini Sector 10"
  },
  "destination": {
    "lat": 28.6315,
    "lon": 77.2167,
    "name": "Connaught Place"
  },
  "travel_mode": "driving",
  "departure_time": "19:00",
  "departure_day": "Friday",
  "use_osrm": true
}
```

**Response (excerpt):**
```json
{
  "id": "e458e0be-683a-4a69-952b-7c9818844888",
  "origin_name": "Rohini Sector 10",
  "destination_name": "Connaught Place",
  "travel_mode": "driving",
  "comparison_summary": "'Via Mahatma Gandhi Marg' has an estimated comparative risk score of 26.0/100...",
  "alternatives": [
    {
      "id": "3bb609b5-fcfb-4890-8e1f-7253503db5b5",
      "route_name": "Via Mahatma Gandhi Marg / Ring Road Arterial",
      "total_distance_m": 16644.0,
      "total_duration_s": 1958.1,
      "overall_risk_score": 26.0,
      "crime_exposure_score": 30.0,
      "recency_score": 15.0,
      "infrastructure_score": 45.0,
      "temporal_score": 45.0,
      "uncertainty_score": 15.0,
      "incident_count": 4,
      "confidence_level": "High",
      "score_breakdown": {
        "crime_exposure": 30.0,
        "incident_recency": 15.0,
        "contextual_infrastructure": 45.0,
        "time_of_day": 45.0,
        "data_uncertainty": 15.0,
        "explanations": ["Low to moderate historical incident density...", "Proximity to police facility buffers risk."]
      },
      "geometry_geojson": { "type": "LineString", "coordinates": [...] },
      "segments": [...]
    }
  ]
}
```

---

## 5. Analytics & Diagnostics

- `GET /api/analytics/overview`: Top-level totals and category breakdowns.
- `GET /api/analytics/timeline`: Monthly time-series points.
- `GET /api/analytics/coverage`: District reporting completeness metrics.
- `GET /api/settings`: Current scoring weights and service status.
- `PATCH /api/settings/{key}`: Dynamically adjusts a scoring weight or setting.
