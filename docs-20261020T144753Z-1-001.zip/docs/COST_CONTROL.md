# External API Cost Control & Optimization Guide

**Platform:** NIRIKSHAK  
**Reference Date:** 2026

---

## 1. Zero-Cost Open Source Default

NIRIKSHAK is architected so that **zero external API costs are incurred** during development and standard operation:
- **Map Display:** OpenStreetMap tile servers via CartoDB Dark Matter (Free, Open Attribution).
- **Routing Engine:** Open Source Routing Machine (OSRM) public API or local Delhi Hub Router (Free, zero marginal cost).
- **Geocoding & Gazetteer:** Built-in Delhi Gazetteer with 60+ pre-calculated GPS coordinates (Zero API calls).
- **NLP Extraction:** Local rule-based and regex heuristic parser with IPC/BNS legal terminology (Free).

---

## 2. Google Maps Platform Cost Model (When Configured)

When an enterprise chooses to enable Google Maps Platform integrations, the following current pricing structure applies:

| Service / API | Pricing Tier | Free Monthly Allowance | Optimization in NIRIKSHAK |
| :--- | :--- | :--- | :--- |
| **Routes API (Compute Routes)** | \$5.00 per 1,000 requests | \$200 Google Cloud credit (~40,000 requests/mo) | Request alternatives only when toggled; cache route geometry |
| **Places API (Autocomplete)** | \$2.83 per 1,000 requests | Covered by monthly credit | Debounce user input by 400ms |
| **Maps JavaScript API** | \$7.00 per 1,000 loads | Covered by monthly credit (~28,000 map loads/mo) | Use Leaflet / OSM for standard map views |
| **Street View Static API** | \$7.00 per 1,000 requests | Covered by monthly credit | Fetch static imagery strictly on segment click; do not prefetch |

---

## 3. Cost-Optimization Best Practices

1. **Client-Side Geocoding Cache:** The Delhi Gazetteer resolves known landmarks locally without external API calls.
2. **Quota Limits in Google Cloud Console:**
   - Set daily hard quotas (e.g., maximum 500 requests/day per API).
   - Configure billing alerts at 50%, 75%, and 90% of budget.
3. **API Key Restriction:** Restrict Google API keys by HTTP referrers (`http://localhost:5173/*`, `https://yourdomain.com/*`) and specific API services to prevent unauthorized usage.
