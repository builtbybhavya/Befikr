# Docker & PostGIS Production Deployment Guide

NIRIKSHAK includes a production-ready `docker-compose.yml` for deploying PostgreSQL with the PostGIS spatial extension.

---

## 1. Prerequisites
- Docker Engine 24+ & Docker Compose v2+
- 4 GB RAM minimum

---

## 2. Docker Compose Configuration

The included `docker-compose.yml` launches three containers:
1. `nirikshak-postgis`: Official `postgis/postgis:16-3.4` database.
2. `nirikshak-backend`: FastAPI application on port 8000.
3. `nirikshak-frontend`: Production Nginx web server on port 5173.

---

## 3. Launching Containers

From the project root:
```bash
docker compose up --build -d
```

Verify service status:
```bash
docker compose ps
docker compose logs -f backend
```

Access services:
- Frontend: `http://localhost:5173`
- Backend API Docs: `http://localhost:8000/docs`
- PostGIS Database: `localhost:5432` (User: `postgres`, Pass: `postgrespassword`)

---

## 4. Stopping Containers
```bash
docker compose down
```
*(To remove database volume: `docker compose down -v`)*
