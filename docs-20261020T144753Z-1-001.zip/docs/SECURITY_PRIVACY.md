# Security, Privacy & Ethical Use Framework

**Platform:** NIRIKSHAK  
**Jurisdiction Context:** National Capital Territory of Delhi, India

---

## 1. Guiding Ethical Principles

NIRIKSHAK is a public-interest research and civic analytics platform. Its objective is to illuminate public safety evidence transparently without compromising individual human rights or civil liberties.

---

## 2. Privacy & Data Protection Safeguards

### A. Strict Coarsening of Coordinates (No Victim Addresses)
- NIRIKSHAK **never geocodes private residential house numbers, apartment units, or victims' private homes**.
- All incidents are resolved to the nearest public road intersection, commercial transit landmark, or administrative locality boundary.
- Minimum geographic resolution is preserved at **locality / street-level**.

### B. No Facial Recognition or Biometric Tracking
- The platform contains zero computer vision routines for facial recognition, suspect identification, or visual demographic tracking.
- Images from street views or public sources are inspected strictly for physical infrastructure markers (street lighting, road width, transit stops).

### C. No Identity Profiling or Predictive Criminality
- NIRIKSHAK **never predicts individual criminality** or scores the trustworthiness of residents.
- Socioeconomic status, caste, religion, ethnicity, income, or demographic composition are **strictly forbidden** from being used as risk proxies.

### D. Distinction Between Allegation and Conviction
- Extracted records explicitly record evidence status:
  - `reported_allegation`: Initial public or media complaint.
  - `police_reported`: Official FIR registered by Delhi Police.
  - `court_confirmed`: Judicial conviction.
- The platform never asserts automatic guilt based merely on a sensational media headline.

---

## 3. Public Provenance & Human-in-the-Loop Review

- Every displayed live incident maintains a direct traceable hyperlink to its original source URL.
- The **Human-in-the-Loop Review Queue** allows analysts and users to dispute, correct, or merge records with an immutable audit log (`VerificationEvent`).
- A prompt injection defense isolates all untrusted web text, preventing external articles from overriding system instructions.

---

## 4. Emergency Disclaimers

> [!CAUTION]
> NIRIKSHAK is not an emergency response service or dispatch mechanism. In active distress situations, users must dial official emergency numbers (**112** or **100**) directly.
