import datetime
from backend.app.services.extraction.extractor import extract_incident_from_text


def test_incident_extraction_theft_and_snatching():
    title = "Chain snatching incident reported in Lajpat Nagar"
    text = "Two unidentified motorcyclists snatched a gold chain from a commuter walking towards Central Market at 8pm. Police have lodged an FIR."
    extracted = extract_incident_from_text(title, text, datetime.datetime(2026, 2, 1, 20, 0))

    assert extracted is not None
    assert extracted["crime_category"] == "Theft and Robbery"
    assert extracted["locality"] == "Lajpat Nagar"
    assert extracted["incident_time_window"] == "night"
    assert extracted["incident_status"] == "police_reported"
    assert extracted["is_synthetic"] is False


def test_incident_extraction_burglary():
    title = "Break-in at electronics shop in Karol Bagh"
    text = "Burglars broke into a mobile shop at Arya Samaj Road past midnight and stole laptops."
    extracted = extract_incident_from_text(title, text)

    assert extracted is not None
    assert extracted["crime_category"] == "Burglary"
    assert extracted["locality"] == "Karol Bagh"
    assert extracted["incident_time_window"] == "late_night"


def test_incident_extraction_non_crime():
    title = "Delhi metro timings revised for festival season"
    text = "DMRC announced that train frequencies on the Yellow Line will increase from tomorrow morning."
    extracted = extract_incident_from_text(title, text)

    assert extracted is None
