import pytest
from fastapi.testclient import TestClient
from backend.app.main import app
from backend.app.db.session import SessionLocal
from backend.app.db.init_db import init_database


@pytest.fixture(scope="module", autouse=True)
def setup_api_database():
    db = SessionLocal()
    init_database(db)
    db.close()


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


def test_api_health(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] in ["operational", "degraded"]
    assert "app_name" in data
    assert data["app_name"] == "NIRIKSHAK"


def test_api_sources_list(client):
    response = client.get("/api/sources")
    assert response.status_code == 200
    sources = response.json()
    assert isinstance(sources, list)
    assert len(sources) > 0


def test_api_incidents_list(client):
    response = client.get("/api/incidents")
    assert response.status_code == 200
    data = response.json()
    assert "total" in data
    assert "incidents" in data
    assert len(data["incidents"]) > 0


def test_api_analytics_overview(client):
    response = client.get("/api/analytics/overview")
    assert response.status_code == 200
    data = response.json()
    assert "total_incidents" in data
    assert "category_distribution" in data


def test_api_route_analysis_workflow(client):
    payload = {
        "origin": {"lat": 28.7118, "lon": 77.1154, "name": "Rohini Sector 10"},
        "destination": {"lat": 28.6315, "lon": 77.2167, "name": "Connaught Place"},
        "travel_mode": "driving",
        "departure_time": "19:00",
        "departure_day": "Friday",
        "use_osrm": False  # Deterministic offline router for swift test
    }
    response = client.post("/api/routes/analyze", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "alternatives" in data
    assert len(data["alternatives"]) >= 2
    assert "comparison_summary" in data
    for alt in data["alternatives"]:
        assert 0.0 <= alt["overall_risk_score"] <= 100.0
        assert alt["geometry_geojson"]["type"] == "LineString"
        assert len(alt["segments"]) > 0
