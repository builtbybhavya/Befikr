from backend.app.services.geocoding.gazetteer import geocode_delhi_text, haversine_distance_meters, DELHI_GAZETTEER


def test_gazetteer_exact_and_alias_matches():
    res1 = geocode_delhi_text("A purse was snatched near Rajiv Chowk metro station")
    assert res1 is not None
    assert res1["name"] == "Connaught Place"
    assert res1["district"] == "New Delhi"
    assert abs(res1["lat"] - 28.6315) < 0.01

    res2 = geocode_delhi_text("Vehicle theft reported in Rohini Sector 10 near market")
    assert res2 is not None
    assert "Rohini" in res2["name"]

    res3 = geocode_delhi_text("Brawl near Netaji Subhash Place NSP food court")
    assert res3 is not None
    assert res3["name"] == "Pitampura"


def test_haversine_distance():
    # Distance between Connaught Place and Rohini Sector 10 is ~14-16 km
    cp = DELHI_GAZETTEER["connaught place"]
    rohini = DELHI_GAZETTEER["rohini sector 10"]
    dist = haversine_distance_meters(cp["lat"], cp["lon"], rohini["lat"], rohini["lon"])
    assert 13000 < dist < 17000

    # Distance to itself should be 0
    assert haversine_distance_meters(cp["lat"], cp["lon"], cp["lat"], cp["lon"]) == 0.0
