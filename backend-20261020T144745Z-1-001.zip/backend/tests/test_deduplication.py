import datetime
from backend.app.models.models import Incident
from backend.app.services.extraction.deduplicator import find_duplicate_incident


def test_deduplication_detects_same_event():
    existing = [
        Incident(
            internal_id="DL-TEST-001",
            original_title="Mobile phone snatched near Rohini Sector 10 flyover",
            crime_category="Theft and Robbery",
            latitude=28.7118,
            longitude=77.1154,
            incident_date=datetime.datetime(2026, 2, 10, 20, 0),
            is_synthetic=False
        )
    ]

    # Candidate with different publisher title for same event
    candidate = {
        "original_title": "Pedestrian robbed of mobile phone near Rohini Sector 10 flyover",
        "crime_category": "Theft and Robbery",
        "latitude": 28.7120,  # ~25m away
        "longitude": 77.1156,
        "incident_date": datetime.datetime(2026, 2, 10, 20, 30)
    }

    dup = find_duplicate_incident(candidate, existing, distance_threshold_m=800.0)
    assert dup is not None
    assert dup.internal_id == "DL-TEST-001"


def test_deduplication_preserves_separate_events():
    existing = [
        Incident(
            internal_id="DL-TEST-001",
            original_title="Mobile phone snatched near Rohini Sector 10",
            crime_category="Theft and Robbery",
            latitude=28.7118,
            longitude=77.1154,
            incident_date=datetime.datetime(2026, 2, 10, 20, 0),
            is_synthetic=False
        )
    ]

    # Candidate in different locality (Connaught Place)
    candidate = {
        "original_title": "Mobile phone snatched near Rajiv Chowk CP",
        "crime_category": "Theft and Robbery",
        "latitude": 28.6315,
        "longitude": 77.2167,
        "incident_date": datetime.datetime(2026, 2, 10, 20, 0)
    }

    dup = find_duplicate_incident(candidate, existing)
    assert dup is None
