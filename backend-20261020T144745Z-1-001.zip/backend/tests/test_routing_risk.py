import datetime
from backend.app.models.models import Incident
from backend.app.services.routing.router import build_route_segments, generate_fallback_delhi_routes
from backend.app.services.risk.engine import evaluate_route_risk


def test_route_segmentation():
    # 2-point coordinates spanning ~1km
    coords = [(28.7118, 77.1154), (28.7150, 77.1190), (28.7200, 77.1230)]
    segments = build_route_segments(coords, target_segment_length_m=150.0)
    assert len(segments) >= 2
    for seg in segments:
        assert "geometry_geojson" in seg
        assert seg["distance_m"] > 0


def test_evaluate_route_risk_scoring():
    coords = [(28.7118, 77.1154), (28.7150, 77.1180), (28.7180, 77.1210)]
    segments = build_route_segments(coords, target_segment_length_m=150.0)

    # Mock incidents along corridor
    incidents = [
        Incident(
            internal_id="TEST-INC-1",
            original_title="Robbery near corridor",
            crime_category="Theft and Robbery",
            severity_category="medium",
            incident_status="police_reported",
            incident_date=datetime.datetime.utcnow(),
            incident_time_window="night",
            latitude=28.7120,
            longitude=77.1155,
            verification_status="verified",
            is_synthetic=True
        )
    ]

    result = evaluate_route_risk(segments, incidents, departure_time_str="21:00", departure_day="Friday")

    assert "overall_risk_score" in result
    assert 0.0 <= result["overall_risk_score"] <= 100.0
    assert "score_breakdown" in result
    assert "explanations" in result["score_breakdown"]
    assert len(result["caveats"]) > 0
    assert result["incident_count"] == 1
