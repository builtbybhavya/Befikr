from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.app.core.config import settings
from backend.app.db.session import SessionLocal
from backend.app.db.init_db import init_database
from backend.app.api.health import router as health_router
from backend.app.api.sources import router as sources_router
from backend.app.api.ingestion import router as ingestion_router
from backend.app.api.incidents import router as incidents_router
from backend.app.api.areas import router as areas_router
from backend.app.api.analytics import router as analytics_router
from backend.app.api.routes import router as routes_router
from backend.app.api.settings import router as settings_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize database schema, seed default sources, gazetteer, and demo fixtures
    db = SessionLocal()
    try:
        init_database(db)
    finally:
        db.close()
    yield
    # Shutdown logic if needed


app = FastAPI(
    title=settings.APP_NAME,
    description="Delhi Crime Intelligence & Route Risk Platform — Understand the evidence. Visualize the risk. Choose your route.",
    version=settings.APP_VERSION,
    lifespan=lifespan
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register API Routers under /api
app.include_router(health_router, prefix="/api")
app.include_router(sources_router, prefix="/api")
app.include_router(ingestion_router, prefix="/api")
app.include_router(incidents_router, prefix="/api")
app.include_router(areas_router, prefix="/api")
app.include_router(analytics_router, prefix="/api")
app.include_router(routes_router, prefix="/api")
app.include_router(settings_router, prefix="/api")


@app.get("/")
def root():
    return {
        "project": settings.APP_NAME,
        "tagline": settings.APP_TAGLINE,
        "version": settings.APP_VERSION,
        "docs_url": "/docs",
        "health_check": "/api/health",
        "demo_mode": settings.DEMO_MODE
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.app.main:app", host=settings.BACKEND_HOST, port=settings.BACKEND_PORT, reload=True)
