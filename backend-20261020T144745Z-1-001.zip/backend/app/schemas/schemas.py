from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict


# --- SOURCES ---
class SourceBase(BaseModel):
    name: str
    url: str
    source_type: str
    reliability_score: float = 0.8
    retrieval_method: str


class SourceCreate(SourceBase):
    pass


class SourceResponse(SourceBase):
    id: int
    last_successful_retrieval: Optional[datetime] = None
    ingestion_status: str
    error_log: Optional[str] = None
    created_at: datetime
    document_count: Optional[int] = 0
    incident_count: Optional[int] = 0

    model_config = ConfigDict(from_attributes=True)


# --- INCIDENTS ---
class IncidentBase(BaseModel):
    internal_id: str
    original_title: str
    original_url: Optional[str] = None
    publisher: Optional[str] = None
    publication_date: Optional[datetime] = None
    incident_date: Optional[datetime] = None
    incident_time_window: str = "unknown"
    crime_category: str
    severity_category: str = "medium"
    description: Optional[str] = None
    named_location: Optional[str] = None
    locality: Optional[str] = None
    police_district: Optional[str] = None
    district: Optional[str] = None
    latitude: float
    longitude: float
    geographic_precision: str = "locality_level"
    incident_status: str = "reported_allegation"
    corroboration_count: int = 1
    extraction_confidence: float = 0.85
    geocoding_confidence: float = 0.85
    verification_status: str = "unverified"
    is_synthetic: bool = False
    source_passage: Optional[str] = None


class IncidentCreate(IncidentBase):
    source_id: Optional[int] = None
    source_document_id: Optional[int] = None


class IncidentResponse(IncidentBase):
    id: int
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class IncidentFilter(BaseModel):
    category: Optional[str] = None
    severity: Optional[str] = None
    verification_status: Optional[str] = None
    locality: Optional[str] = None
    is_synthetic: Optional[bool] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    search: Optional[str] = None
    limit: int = 100
    offset: int = 0


class IncidentListResponse(BaseModel):
    total: int
    incidents: List[IncidentResponse]
    offset: int
    limit: int


class IncidentVerifyRequest(BaseModel):
    status: str = "verified"  # verified, disputed, rejected
    notes: Optional[str] = None
    performed_by: str = "analyst"


class IncidentCorrectRequest(BaseModel):
    crime_category: Optional[str] = None
    severity_category: Optional[str] = None
    incident_date: Optional[datetime] = None
    locality: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    geographic_precision: Optional[str] = None
    notes: Optional[str] = None
    performed_by: str = "analyst"


# --- GEOGRAPHIC AREAS ---
class GeographicAreaResponse(BaseModel):
    id: int
    name: str
    area_type: str
    center_lat: float
    center_lon: float
    bounding_box: Optional[str] = None
    risk_index: float
    incident_count: int
    data_coverage_score: float

    model_config = ConfigDict(from_attributes=True)


# --- ROUTES & RISK ---
class Coordinate(BaseModel):
    lat: float
    lon: float
    name: Optional[str] = None


class RouteRequest(BaseModel):
    origin: Coordinate
    destination: Coordinate
    travel_mode: str = "driving"  # driving, walking, cycling
    departure_time: str = "18:00"
    departure_day: str = "Friday"
    use_osrm: bool = True


class RouteSegmentResponse(BaseModel):
    id: Optional[int] = None
    segment_index: int
    start_lat: float
    start_lon: float
    end_lat: float
    end_lon: float
    distance_m: float
    duration_s: float
    segment_risk_score: float
    nearby_incident_count: int
    street_lighting_status: str
    road_type: str
    commercial_activity: str
    police_facility_nearby: bool
    transit_station_nearby: bool
    geometry_geojson: Dict[str, Any]
    nearby_incidents: Optional[List[Dict[str, Any]]] = None

    model_config = ConfigDict(from_attributes=True)


class ScoreBreakdown(BaseModel):
    crime_exposure: float
    incident_recency: float
    contextual_infrastructure: float
    time_of_day: float
    data_uncertainty: float
    weights: Dict[str, float]
    explanations: List[str]


class RouteAlternativeResponse(BaseModel):
    id: str
    alternative_index: int
    provider: str
    route_name: str
    total_distance_m: float
    total_duration_s: float
    overall_risk_score: float
    crime_exposure_score: float
    recency_score: float
    infrastructure_score: float
    temporal_score: float
    uncertainty_score: float
    incident_count: int
    confidence_level: str
    score_breakdown: ScoreBreakdown
    caveats: List[str]
    geometry_geojson: Dict[str, Any]
    segments: Optional[List[RouteSegmentResponse]] = None

    model_config = ConfigDict(from_attributes=True)


class RouteAnalysisResponse(BaseModel):
    id: str
    origin_name: str
    origin_lat: float
    origin_lon: float
    destination_name: str
    destination_lat: float
    destination_lon: float
    travel_mode: str
    departure_time: str
    departure_day: str
    created_at: datetime
    comparison_summary: str
    alternatives: List[RouteAlternativeResponse]

    model_config = ConfigDict(from_attributes=True)


# --- ANALYTICS ---
class AnalyticsOverviewResponse(BaseModel):
    total_sources: int
    total_documents: int
    total_incidents: int
    verified_incidents: int
    unverified_incidents: int
    synthetic_incidents: int
    live_incidents: int
    last_update: Optional[datetime] = None
    data_coverage_percentage: float
    category_distribution: Dict[str, int]
    severity_distribution: Dict[str, int]
    district_distribution: Dict[str, int]


class TimelinePoint(BaseModel):
    date: str
    count: int
    categories: Dict[str, int]


# --- SETTINGS ---
class SettingUpdate(BaseModel):
    value: str
    category: Optional[str] = None
    description: Optional[str] = None
