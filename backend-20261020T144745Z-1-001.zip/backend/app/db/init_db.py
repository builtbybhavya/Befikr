import json
from sqlalchemy.orm import Session
from backend.app.db.base import Base
from backend.app.db.session import engine
from backend.app.models.models import Source, GeographicArea, Incident, ApplicationSetting
from backend.app.services.ingestion.sources import DEFAULT_DELHI_SOURCES
from backend.app.services.geocoding.gazetteer import DELHI_GAZETTEER
from data.fixtures.delhi_demo_data import SYNTHETIC_INCIDENTS
from backend.app.core.config import settings


def init_database(db: Session):
    """
    Creates tables and seeds initial sources, geographic gazetteer areas,
    and synthetic demo fixtures when demo mode is active.
    """
    # 1. Create tables
    Base.metadata.create_all(bind=engine)

    # 2. Seed default sources
    existing_sources = db.query(Source).count()
    if existing_sources == 0:
        for s_data in DEFAULT_DELHI_SOURCES:
            src = Source(
                name=s_data["name"],
                url=s_data["url"],
                source_type=s_data["source_type"],
                reliability_score=s_data["reliability_score"],
                retrieval_method=s_data["retrieval_method"],
                ingestion_status=s_data["ingestion_status"]
            )
            db.add(src)
        db.commit()

    # 3. Seed Geographic Areas from Gazetteer
    existing_areas = db.query(GeographicArea).count()
    if existing_areas == 0:
        # NCT Root
        nct_area = GeographicArea(
            name="National Capital Territory of Delhi",
            area_type="nct",
            center_lat=28.6139,
            center_lon=77.2090,
            risk_index=48.5,
            incident_count=12,
            data_coverage_score=0.85
        )
        db.add(nct_area)
        db.commit()
        db.refresh(nct_area)

        for key, gdata in DELHI_GAZETTEER.items():
            area = GeographicArea(
                name=gdata["name"],
                area_type=gdata.get("precision", "locality_level"),
                parent_id=nct_area.id,
                center_lat=gdata["lat"],
                center_lon=gdata["lon"],
                risk_index=45.0,
                incident_count=1,
                data_coverage_score=0.80
            )
            db.add(area)
        db.commit()

    # 4. Seed Synthetic Incidents in Demo Mode
    if settings.DEMO_MODE:
        existing_incidents = db.query(Incident).count()
        if existing_incidents == 0:
            demo_source = db.query(Source).filter(Source.source_type == "user_upload").first()
            source_id = demo_source.id if demo_source else None

            for inc_data in SYNTHETIC_INCIDENTS:
                inc = Incident(
                    internal_id=inc_data["internal_id"],
                    source_id=source_id,
                    original_title=inc_data["original_title"],
                    original_url=inc_data["original_url"],
                    publisher=inc_data["publisher"],
                    publication_date=inc_data["publication_date"],
                    incident_date=inc_data["incident_date"],
                    incident_time_window=inc_data["incident_time_window"],
                    crime_category=inc_data["crime_category"],
                    severity_category=inc_data["severity_category"],
                    description=inc_data["description"],
                    named_location=inc_data["named_location"],
                    locality=inc_data["locality"],
                    police_district=inc_data["police_district"],
                    district=inc_data["district"],
                    latitude=inc_data["latitude"],
                    longitude=inc_data["longitude"],
                    geographic_precision=inc_data["geographic_precision"],
                    incident_status=inc_data["incident_status"],
                    corroboration_count=inc_data["corroboration_count"],
                    extraction_confidence=inc_data["extraction_confidence"],
                    geocoding_confidence=inc_data["geocoding_confidence"],
                    verification_status=inc_data["verification_status"],
                    is_synthetic=True,
                    source_passage=inc_data["source_passage"]
                )
                db.add(inc)
            db.commit()

    # 5. Initialize application settings
    default_settings = [
        {"key": "weight_crime_exposure", "value": str(settings.WEIGHT_CRIME_EXPOSURE), "category": "scoring", "description": "Weight of historical crime incident exposure (0.0 - 1.0)"},
        {"key": "weight_incident_recency", "value": str(settings.WEIGHT_INCIDENT_RECENCY), "category": "scoring", "description": "Weight of recency exponential decay factor (0.0 - 1.0)"},
        {"key": "weight_contextual_infrastructure", "value": str(settings.WEIGHT_CONTEXTUAL_INFRASTRUCTURE), "category": "scoring", "description": "Weight of street lighting, transit hubs, and police posts (0.0 - 1.0)"},
        {"key": "weight_time_of_day", "value": str(settings.WEIGHT_TIME_OF_DAY), "category": "scoring", "description": "Weight of departure time vs incident temporal windows (0.0 - 1.0)"},
        {"key": "weight_data_uncertainty", "value": str(settings.WEIGHT_DATA_UNCERTAINTY), "category": "scoring", "description": "Weight of data uncertainty penalty (0.0 - 1.0)"},
        {"key": "demo_mode", "value": str(settings.DEMO_MODE).lower(), "category": "system", "description": "Whether synthetic demo mode is enabled"}
    ]
    for s in default_settings:
        existing = db.query(ApplicationSetting).filter(ApplicationSetting.key == s["key"]).first()
        if not existing:
            db.add(ApplicationSetting(key=s["key"], value=s["value"], category=s["category"], description=s["description"]))
    db.commit()
