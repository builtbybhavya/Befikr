import datetime
import uuid
from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    Boolean,
    DateTime,
    Text,
    ForeignKey,
    Index
)
from sqlalchemy.orm import relationship
from backend.app.db.base import Base


class Source(Base):
    __tablename__ = "sources"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    url = Column(String(1024), nullable=False)
    source_type = Column(String(50), nullable=False)  # official, news, open_data, user_upload
    reliability_score = Column(Float, default=0.8)    # 0.0 to 1.0
    retrieval_method = Column(String(50), nullable=False)  # rss, scrape, api, upload
    last_successful_retrieval = Column(DateTime, nullable=True)
    ingestion_status = Column(String(50), default="idle")  # idle, active, error, pending
    error_log = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    documents = relationship("SourceDocument", back_populates="source", cascade="all, delete-orphan")
    incidents = relationship("Incident", back_populates="source")


class SourceDocument(Base):
    __tablename__ = "source_documents"

    id = Column(Integer, primary_key=True, index=True)
    source_id = Column(Integer, ForeignKey("sources.id"), nullable=True)
    title = Column(String(500), nullable=False)
    url = Column(String(1024), nullable=True)
    content_raw = Column(Text, nullable=True)
    content_clean = Column(Text, nullable=True)
    publication_date = Column(DateTime, nullable=True)
    document_format = Column(String(50), default="html")  # html, pdf, rss_item, csv, json
    sha256_hash = Column(String(64), nullable=True, index=True)
    ingested_at = Column(DateTime, default=datetime.datetime.utcnow)

    source = relationship("Source", back_populates="documents")
    incidents = relationship("Incident", back_populates="source_document")


class Incident(Base):
    __tablename__ = "incidents"

    id = Column(Integer, primary_key=True, index=True)
    internal_id = Column(String(64), unique=True, index=True, nullable=False)
    source_id = Column(Integer, ForeignKey("sources.id"), nullable=True)
    source_document_id = Column(Integer, ForeignKey("source_documents.id"), nullable=True)

    original_title = Column(String(500), nullable=False)
    original_url = Column(String(1024), nullable=True)
    publisher = Column(String(255), nullable=True)
    publication_date = Column(DateTime, nullable=True)
    incident_date = Column(DateTime, nullable=True, index=True)
    incident_time_window = Column(String(50), default="unknown")  # early_morning, morning, afternoon, evening, night, late_night, unknown

    crime_category = Column(String(100), nullable=False, index=True)
    severity_category = Column(String(50), default="medium")  # low, medium, high, critical
    description = Column(Text, nullable=True)
    
    named_location = Column(String(255), nullable=True)
    locality = Column(String(255), nullable=True, index=True)
    police_district = Column(String(255), nullable=True)
    district = Column(String(255), nullable=True, index=True)
    
    latitude = Column(Float, nullable=False, index=True)
    longitude = Column(Float, nullable=False, index=True)
    geographic_precision = Column(String(50), default="locality_level")  # exact, street_level, locality_level, district_level, unknown
    
    incident_status = Column(String(100), default="reported_allegation")  # reported_allegation, police_reported, official_statistic, court_confirmed
    corroboration_count = Column(Integer, default=1)
    extraction_confidence = Column(Float, default=0.85)
    geocoding_confidence = Column(Float, default=0.85)
    verification_status = Column(String(50), default="unverified")  # unverified, verified, disputed, rejected
    
    is_synthetic = Column(Boolean, default=False, index=True)  # CRITICAL: Distinguishes synthetic sample demo from real live sources
    source_passage = Column(Text, nullable=True)
    
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    source = relationship("Source", back_populates="incidents")
    source_document = relationship("SourceDocument", back_populates="incidents")
    verification_events = relationship("VerificationEvent", back_populates="incident", cascade="all, delete-orphan")


class GeographicArea(Base):
    __tablename__ = "geographic_areas"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    area_type = Column(String(50), nullable=False)  # nct, district, police_district, locality
    parent_id = Column(Integer, ForeignKey("geographic_areas.id"), nullable=True)
    center_lat = Column(Float, nullable=False)
    center_lon = Column(Float, nullable=False)
    bounding_box = Column(Text, nullable=True)  # JSON string [min_lon, min_lat, max_lon, max_lat]
    risk_index = Column(Float, default=50.0)
    incident_count = Column(Integer, default=0)
    data_coverage_score = Column(Float, default=0.7)


class RouteAnalysis(Base):
    __tablename__ = "route_analyses"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    origin_name = Column(String(255), nullable=False)
    origin_lat = Column(Float, nullable=False)
    origin_lon = Column(Float, nullable=False)
    destination_name = Column(String(255), nullable=False)
    destination_lat = Column(Float, nullable=False)
    destination_lon = Column(Float, nullable=False)
    travel_mode = Column(String(50), default="driving")
    departure_time = Column(String(20), default="18:00")
    departure_day = Column(String(20), default="Friday")
    comparison_summary = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    alternatives = relationship("RouteAlternative", back_populates="analysis", cascade="all, delete-orphan")


class RouteAlternative(Base):
    __tablename__ = "route_alternatives"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    analysis_id = Column(String(36), ForeignKey("route_analyses.id"), nullable=False)
    alternative_index = Column(Integer, default=0)
    provider = Column(String(50), default="osrm")  # osrm, google, offline_hub
    route_name = Column(String(255), nullable=False)
    total_distance_m = Column(Float, nullable=False)
    total_duration_s = Column(Float, nullable=False)

    overall_risk_score = Column(Float, nullable=False)  # 0 to 100
    crime_exposure_score = Column(Float, nullable=False)
    recency_score = Column(Float, nullable=False)
    infrastructure_score = Column(Float, nullable=False)
    temporal_score = Column(Float, nullable=False)
    uncertainty_score = Column(Float, nullable=False)

    incident_count = Column(Integer, default=0)
    confidence_level = Column(String(50), default="Moderate")  # High, Moderate, Low, Insufficient Data
    score_breakdown = Column(Text, nullable=True)  # JSON string
    caveats = Column(Text, nullable=True)          # JSON list of strings
    geometry_geojson = Column(Text, nullable=False) # JSON LineString

    analysis = relationship("RouteAnalysis", back_populates="alternatives")
    segments = relationship("RouteSegment", back_populates="alternative", cascade="all, delete-orphan")


class RouteSegment(Base):
    __tablename__ = "route_segments"

    id = Column(Integer, primary_key=True, index=True)
    alternative_id = Column(String(36), ForeignKey("route_alternatives.id"), nullable=False)
    segment_index = Column(Integer, nullable=False)
    start_lat = Column(Float, nullable=False)
    start_lon = Column(Float, nullable=False)
    end_lat = Column(Float, nullable=False)
    end_lon = Column(Float, nullable=False)
    distance_m = Column(Float, nullable=False)
    duration_s = Column(Float, nullable=False)
    segment_risk_score = Column(Float, default=0.0)  # 0 to 100
    nearby_incident_count = Column(Integer, default=0)

    street_lighting_status = Column(String(50), default="unknown")  # adequate, moderate, poor, unknown
    road_type = Column(String(50), default="arterial")               # highway, arterial, collector, local
    commercial_activity = Column(String(50), default="moderate")     # high, moderate, low, isolated
    police_facility_nearby = Column(Boolean, default=False)
    transit_station_nearby = Column(Boolean, default=False)
    geometry_geojson = Column(Text, nullable=False)

    alternative = relationship("RouteAlternative", back_populates="segments")


class SegmentIncidentAssociation(Base):
    __tablename__ = "segment_incident_associations"

    id = Column(Integer, primary_key=True, index=True)
    segment_id = Column(Integer, ForeignKey("route_segments.id"), nullable=False)
    incident_id = Column(String(64), nullable=False)
    distance_m = Column(Float, nullable=False)
    impact_score = Column(Float, default=1.0)


class VerificationEvent(Base):
    __tablename__ = "verification_events"

    id = Column(Integer, primary_key=True, index=True)
    incident_id = Column(Integer, ForeignKey("incidents.id"), nullable=False)
    action = Column(String(50), nullable=False)  # verified, corrected, disputed, rejected, merged
    performed_by = Column(String(100), default="analyst")
    notes = Column(Text, nullable=True)
    previous_data = Column(Text, nullable=True)  # JSON
    new_data = Column(Text, nullable=True)       # JSON
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)

    incident = relationship("Incident", back_populates="verification_events")


class ApplicationSetting(Base):
    __tablename__ = "application_settings"

    key = Column(String(100), primary_key=True)
    value = Column(Text, nullable=False)
    category = Column(String(50), default="general")
    description = Column(String(500), nullable=True)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
