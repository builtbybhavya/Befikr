from typing import List, Dict, Any

DEFAULT_DELHI_SOURCES: List[Dict[str, Any]] = [
    {
        "name": "Delhi Police Public Notices & Bulletins",
        "url": "https://delhipolice.gov.in/press-release",
        "source_type": "official",
        "reliability_score": 0.95,
        "retrieval_method": "scrape",
        "ingestion_status": "idle"
    },
    {
        "name": "NCRB Delhi Crime Statistical Publications",
        "url": "https://ncrb.gov.in/en/crime-in-india",
        "source_type": "official",
        "reliability_score": 0.95,
        "retrieval_method": "upload",
        "ingestion_status": "idle"
    },
    {
        "name": "The Indian Express - Delhi City & Crime",
        "url": "https://indianexpress.com/section/cities/delhi/feed/",
        "source_type": "news",
        "reliability_score": 0.88,
        "retrieval_method": "rss",
        "ingestion_status": "idle"
    },
    {
        "name": "Times of India - Delhi Crime Beat",
        "url": "https://timesofindia.indiatimes.com/rssfeeds/-2128838597.cms",
        "source_type": "news",
        "reliability_score": 0.82,
        "retrieval_method": "rss",
        "ingestion_status": "idle"
    },
    {
        "name": "The Hindu - Delhi Region Reporting",
        "url": "https://www.thehindu.com/news/cities/Delhi/feeder/default.rss",
        "source_type": "news",
        "reliability_score": 0.88,
        "retrieval_method": "rss",
        "ingestion_status": "idle"
    },
    {
        "name": "Data.gov.in & Delhi Open Data Portal",
        "url": "https://data.gov.in/keywords/delhi-crime",
        "source_type": "open_data",
        "reliability_score": 0.90,
        "retrieval_method": "api",
        "ingestion_status": "idle"
    },
    {
        "name": "User Upload & Public FIR Registry",
        "url": "local://user-uploads",
        "source_type": "user_upload",
        "reliability_score": 0.75,
        "retrieval_method": "upload",
        "ingestion_status": "idle"
    }
]
