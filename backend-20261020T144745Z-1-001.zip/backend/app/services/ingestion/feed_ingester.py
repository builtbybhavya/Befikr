import datetime
import uuid
import httpx
import feedparser
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from backend.app.models.models import Source, SourceDocument, Incident
from backend.app.services.extraction.extractor import extract_incident_from_text
from backend.app.services.extraction.deduplicator import find_duplicate_incident


async def sync_source_feed(source: Source, db: Session) -> Dict[str, Any]:
    """
    Fetches RSS feed or public articles from a registered source,
    extracts incidents, deduplicates against existing records, and commits to DB.
    """
    source.ingestion_status = "active"
    db.commit()

    total_fetched = 0
    new_incidents_count = 0
    deduped_count = 0

    try:
        if source.retrieval_method == "rss":
            async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as client:
                headers = {"User-Agent": "NIRIKSHAK-Crime-Intel-Bot/1.0 (+https://github.com/nirikshak)"}
                resp = await client.get(source.url, headers=headers)
                resp.raise_for_status()
                feed_data = feedparser.parse(resp.text)

                existing_incidents = db.query(Incident).filter(Incident.is_synthetic == False).all()

                for entry in feed_data.entries[:15]:  # Process recent 15 entries
                    total_fetched += 1
                    title = getattr(entry, "title", "")
                    summary = getattr(entry, "summary", "") or getattr(entry, "description", "")
                    link = getattr(entry, "link", source.url)
                    
                    pub_date = None
                    if hasattr(entry, "published_parsed") and entry.published_parsed:
                        pub_date = datetime.datetime(*entry.published_parsed[:6])

                    # Extract structured incident
                    extracted = extract_incident_from_text(
                        title=title,
                        text=summary,
                        pub_date=pub_date,
                        source_url=link,
                        publisher=source.name
                    )

                    if not extracted:
                        continue

                    # Check for duplicate
                    dup = find_duplicate_incident(extracted, existing_incidents)
                    if dup:
                        dup.corroboration_count += 1
                        deduped_count += 1
                    else:
                        inc_id = f"DL-LIVE-{uuid.uuid4().hex[:8].upper()}"
                        new_inc = Incident(
                            internal_id=inc_id,
                            source_id=source.id,
                            original_title=extracted["original_title"],
                            original_url=extracted["original_url"],
                            publisher=extracted["publisher"],
                            publication_date=extracted["publication_date"],
                            incident_date=extracted["incident_date"],
                            incident_time_window=extracted["incident_time_window"],
                            crime_category=extracted["crime_category"],
                            severity_category=extracted["severity_category"],
                            description=extracted["description"],
                            named_location=extracted["named_location"],
                            locality=extracted["locality"],
                            police_district=extracted["police_district"],
                            district=extracted["district"],
                            latitude=extracted["latitude"],
                            longitude=extracted["longitude"],
                            geographic_precision=extracted["geographic_precision"],
                            incident_status=extracted["incident_status"],
                            corroboration_count=1,
                            extraction_confidence=extracted["extraction_confidence"],
                            geocoding_confidence=extracted["geocoding_confidence"],
                            verification_status=extracted["verification_status"],
                            is_synthetic=False,
                            source_passage=extracted["source_passage"]
                        )
                        db.add(new_inc)
                        existing_incidents.append(new_inc)
                        new_incidents_count += 1

        source.ingestion_status = "idle"
        source.last_successful_retrieval = datetime.datetime.utcnow()
        source.error_log = None
        db.commit()

        return {
            "status": "success",
            "source_id": source.id,
            "fetched": total_fetched,
            "new_incidents": new_incidents_count,
            "deduplicated": deduped_count
        }

    except Exception as e:
        source.ingestion_status = "error"
        source.error_log = str(e)
        db.commit()
        return {
            "status": "error",
            "source_id": source.id,
            "error": str(e),
            "fetched": total_fetched,
            "new_incidents": new_incidents_count
        }
