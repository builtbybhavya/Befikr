import io
import csv
import json
import pymupdf
from typing import List, Dict, Any, Optional


def parse_pdf_document(file_bytes: bytes) -> str:
    """Extracts text content from PDF file bytes using PyMuPDF."""
    doc = pymupdf.open(stream=file_bytes, filetype="pdf")
    text_parts = []
    for page_num in range(len(doc)):
        page = doc.load_page(page_num)
        text = page.get_text()
        if text.strip():
            text_parts.append(text.strip())
    return "\n\n".join(text_parts)


def parse_csv_records(file_bytes: bytes) -> List[Dict[str, Any]]:
    """Parses tabular crime records from CSV file."""
    text_content = file_bytes.decode("utf-8", errors="replace")
    reader = csv.DictReader(io.StringIO(text_content))
    records = []
    for row in reader:
        records.append({k.strip(): v.strip() for k, v in row.items() if k})
    return records


def parse_json_records(file_bytes: bytes) -> List[Dict[str, Any]]:
    """Parses JSON list or structured object containing crime incident records."""
    data = json.loads(file_bytes.decode("utf-8", errors="replace"))
    if isinstance(data, list):
        return data
    elif isinstance(data, dict):
        if "incidents" in data and isinstance(data["incidents"], list):
            return data["incidents"]
        return [data]
    return []
