import re
import datetime
from typing import Dict, Any, Optional, Tuple
from backend.app.services.geocoding.gazetteer import geocode_delhi_text


# Indian Penal Code / Bharatiya Nyaya Sanhita Crime Category Taxonomy
CATEGORY_PATTERNS = {
    "Theft and Robbery": [
        r"\b(theft|stolen|robbed|robbery|snatching|snatched|chain snatching|phone snatching|bag snatching|extortion|looting|dacoity)\b"
    ],
    "Vehicle Theft": [
        r"\b(vehicle theft|car stolen|bike stolen|motorcycle stolen|auto theft|stolen suv|carjacking|stolen vehicle)\b"
    ],
    "Burglary": [
        r"\b(burglary|housebreak|housebreaking|break-in|burgled|shop burglary)\b"
    ],
    "Assault and Violent Crime": [
        r"\b(assault|assaulted|stabbed|stabbing|firing|fired upon|gunshot|physical violence|attacked|battered|grievous hurt|brawl)\b"
    ],
    "Sexual Offences": [
        r"\b(sexual assault|molestation|molested|rape|eve teasing|harassment of woman|outraging modesty|posco)\b"
    ],
    "Kidnapping and Abduction": [
        r"\b(kidnapping|kidnapped|abduction|abducted|ransom demand|hostage)\b"
    ],
    "Homicide": [
        r"\b(murder|murdered|homicide|culpable homicide|killed|lynched|manslaughter)\b"
    ],
    "Cybercrime and Financial Fraud": [
        r"\b(cyber fraud|cybercrime|digital arrest|cheated|phishing|banking fraud|financial fraud|fake call centre|investment scam)\b"
    ],
    "Public Order Incidents": [
        r"\b(riot|rioting|stone pelting|unlawful assembly|vandalism|public nuisance|road rage|clash)\b"
    ]
}

SEVERITY_MAPPING = {
    "Homicide": "critical",
    "Sexual Offences": "critical",
    "Kidnapping and Abduction": "high",
    "Assault and Violent Crime": "high",
    "Theft and Robbery": "medium",
    "Vehicle Theft": "medium",
    "Burglary": "medium",
    "Public Order Incidents": "medium",
    "Cybercrime and Financial Fraud": "low",
    "Other": "low"
}

TIME_WINDOW_PATTERNS = {
    "late_night": r"\b(midnight|late night|1\s?am|2\s?am|3\s?am|4\s?am|past midnight)\b",
    "early_morning": r"\b(early morning|5\s?am|6\s?am|dawn|daybreak)\b",
    "morning": r"\b(morning|7\s?am|8\s?am|9\s?am|10\s?am|11\s?am)\b",
    "afternoon": r"\b(afternoon|noon|12\s?pm|1\s?pm|2\s?pm|3\s?pm|4\s?pm)\b",
    "evening": r"\b(evening|5\s?pm|6\s?pm|7\s?pm|dusk)\b",
    "night": r"\b(night|8\s?pm|9\s?pm|10\s?pm|11\s?pm)\b"
}


def extract_incident_from_text(
    title: str,
    text: str,
    pub_date: Optional[datetime.datetime] = None,
    source_url: str = "",
    publisher: str = "News Feed"
) -> Optional[Dict[str, Any]]:
    """
    Extracts structured Delhi crime incident record from news report or official bulletin.
    Applies privacy rules: no victim address, coarsens coordinates to verified locality.
    """
    full_text = f"{title}\n{text}".lower()

    # 1. Classify Category
    matched_category = "Other"
    for category, patterns in CATEGORY_PATTERNS.items():
        for pat in patterns:
            if re.search(pat, full_text):
                matched_category = category
                break
        if matched_category != "Other":
            break

    # If neither category nor crime terms found, this is not a crime incident
    if matched_category == "Other":
        crime_indicators = ["police", "arrested", "fir", "accused", "victim", "crime", "incident", "investigation"]
        if not any(ci in full_text for ci in crime_indicators):
            return None

    # 2. Extract Locality within NCT of Delhi
    geo_data = geocode_delhi_text(full_text)
    if not geo_data:
        # Default to Central Delhi / New Delhi baseline with unknown precision
        geo_data = {
            "name": "Delhi NCT (General)",
            "district": "Central Delhi",
            "police_district": "Central",
            "lat": 28.6139,
            "lon": 77.2090,
            "precision": "district_level"
        }

    # 3. Detect Time Window
    detected_time_window = "unknown"
    for tw, pat in TIME_WINDOW_PATTERNS.items():
        if re.search(pat, full_text):
            detected_time_window = tw
            break

    # 4. Severity classification
    severity = SEVERITY_MAPPING.get(matched_category, "medium")

    # 5. Extract neutral description (first 2-3 sentences, strip privacy details)
    clean_lines = [line.strip() for line in text.split("\n") if len(line.strip()) > 30]
    description = clean_lines[0] if clean_lines else title
    if len(description) > 300:
        description = description[:297] + "..."

    # 6. Status of Incident
    status = "reported_allegation"
    if any(k in full_text for k in ["police arrested", "fir registered", "police said", "lodged an fir", "fir lodged", "police report", "chargesheet"]):
        status = "police_reported"
    elif "court convicted" in full_text or "court confirmed" in full_text or "convicted by" in full_text:
        status = "court_confirmed"

    # Extraction confidence scoring based on completeness
    confidence = 0.70
    if geo_data["precision"] in ["exact", "street_level"]:
        confidence += 0.15
    if detected_time_window != "unknown":
        confidence += 0.05
    if matched_category != "Other":
        confidence += 0.05
    confidence = min(0.98, confidence)

    return {
        "original_title": title[:500],
        "original_url": source_url,
        "publisher": publisher,
        "publication_date": pub_date or datetime.datetime.utcnow(),
        "incident_date": pub_date or datetime.datetime.utcnow(),
        "incident_time_window": detected_time_window,
        "crime_category": matched_category,
        "severity_category": severity,
        "description": description,
        "named_location": geo_data["name"],
        "locality": geo_data["name"],
        "police_district": geo_data.get("police_district"),
        "district": geo_data.get("district"),
        "latitude": geo_data["lat"],
        "longitude": geo_data["lon"],
        "geographic_precision": geo_data.get("precision", "locality_level"),
        "incident_status": status,
        "corroboration_count": 1,
        "extraction_confidence": round(confidence, 2),
        "geocoding_confidence": 0.90 if geo_data["precision"] != "district_level" else 0.50,
        "verification_status": "unverified",
        "is_synthetic": False,
        "source_passage": text[:400] if text else title
    }
