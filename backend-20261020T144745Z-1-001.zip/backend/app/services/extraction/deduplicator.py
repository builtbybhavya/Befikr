import datetime
from typing import Optional, List, Tuple
from backend.app.services.geocoding.gazetteer import haversine_distance_meters
from backend.app.models.models import Incident


def jaccard_similarity(text1: str, text2: str) -> float:
    """Computes word-level Jaccard similarity between two texts."""
    words1 = set(text1.lower().split())
    words2 = set(text2.lower().split())
    if not words1 or not words2:
        return 0.0
    intersection = len(words1.intersection(words2))
    union = len(words1.union(words2))
    return intersection / union if union > 0 else 0.0


def find_duplicate_incident(
    candidate: dict,
    existing_incidents: List[Incident],
    distance_threshold_m: float = 800.0,
    time_window_days: int = 3,
    title_similarity_threshold: float = 0.35
) -> Optional[Incident]:
    """
    Checks if a candidate incident corresponds to an already recorded incident.
    Returns the existing Incident object if duplicate match is found, else None.
    """
    c_lat = candidate.get("latitude")
    c_lon = candidate.get("longitude")
    c_date = candidate.get("incident_date") or candidate.get("publication_date")
    c_cat = candidate.get("crime_category")
    c_title = candidate.get("original_title", "")

    if c_lat is None or c_lon is None:
        return None

    for existing in existing_incidents:
        # 1. Category must match or be closely related
        if existing.crime_category != c_cat:
            continue

        # 2. Date proximity check
        e_date = existing.incident_date or existing.publication_date
        if c_date and e_date:
            day_diff = abs((c_date - e_date).total_seconds()) / 86400.0
            if day_diff > time_window_days:
                continue

        # 3. Spatial proximity check
        dist = haversine_distance_meters(c_lat, c_lon, existing.latitude, existing.longitude)
        if dist > distance_threshold_m:
            continue

        # 4. Lexical title/content similarity
        sim = jaccard_similarity(c_title, existing.original_title)
        if sim >= title_similarity_threshold:
            return existing

    return None
