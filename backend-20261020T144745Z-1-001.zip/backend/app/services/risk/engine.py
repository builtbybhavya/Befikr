import math
import datetime
from typing import List, Dict, Any, Tuple
from backend.app.core.config import settings
from backend.app.models.models import Incident
from backend.app.services.geocoding.gazetteer import haversine_distance_meters

SEVERITY_WEIGHTS = {
    "Homicide": 4.0,
    "Sexual Offences": 4.0,
    "Kidnapping and Abduction": 3.5,
    "Assault and Violent Crime": 3.0,
    "Theft and Robbery": 2.0,
    "Vehicle Theft": 1.5,
    "Burglary": 1.5,
    "Public Order Incidents": 1.5,
    "Cybercrime and Financial Fraud": 1.0,
    "Other": 1.0
}

STATUS_WEIGHTS = {
    "court_confirmed": 1.0,
    "official_statistic": 0.95,
    "police_reported": 0.90,
    "reported_allegation": 0.70
}

TIME_WINDOW_HOURS = {
    "late_night": (0, 5),
    "early_morning": (5, 8),
    "morning": (8, 12),
    "afternoon": (12, 17),
    "evening": (17, 21),
    "night": (21, 24)
}


def get_time_window_from_hour(hour: int) -> str:
    for window, (start, end) in TIME_WINDOW_HOURS.items():
        if start <= hour < end:
            return window
    return "night"


def calculate_segment_risk(
    segment: Dict[str, Any],
    all_incidents: List[Incident],
    departure_hour: int = 18,
    buffer_radius_m: float = 250.0,
    half_life_days: float = 180.0
) -> Tuple[float, List[Dict[str, Any]], Dict[str, float]]:
    """
    Computes risk score and associated incidents for a single route segment.
    """
    seg_lat = (segment["start_lat"] + segment["end_lat"]) / 2.0
    seg_lon = (segment["start_lon"] + segment["end_lon"]) / 2.0
    now = datetime.datetime.utcnow()

    associated_incidents = []
    exposure_sum = 0.0
    recency_sum = 0.0
    temporal_mismatch_penalty = 0.0

    dep_window = get_time_window_from_hour(departure_hour)

    for inc in all_incidents:
        dist = haversine_distance_meters(seg_lat, seg_lon, inc.latitude, inc.longitude)
        if dist <= buffer_radius_m:
            # 1. Spatial proximity factor (1.0 at 0m, 0.5 at buffer boundary)
            spatial_factor = 1.0 - (dist / buffer_radius_m) * 0.5
            
            # 2. Category & severity weight
            cat_weight = SEVERITY_WEIGHTS.get(inc.crime_category, 1.5)
            stat_weight = STATUS_WEIGHTS.get(inc.incident_status, 0.7)

            # 3. Recency decay
            inc_date = inc.incident_date or inc.publication_date or now
            age_days = max(0.0, (now - inc_date).total_seconds() / 86400.0)
            recency_weight = math.exp(-math.log(2) * age_days / half_life_days)
            recency_sum += recency_weight

            # 4. Time of day correlation
            time_match_factor = 1.0
            if inc.incident_time_window != "unknown":
                if inc.incident_time_window == dep_window:
                    time_match_factor = 1.4  # Higher risk during same departure window
                elif dep_window in ["night", "late_night"] and inc.incident_time_window in ["night", "late_night"]:
                    time_match_factor = 1.3
                else:
                    time_match_factor = 0.8

            impact = cat_weight * stat_weight * spatial_factor * recency_weight * time_match_factor
            exposure_sum += impact

            associated_incidents.append({
                "internal_id": inc.internal_id,
                "title": inc.original_title,
                "category": inc.crime_category,
                "severity": inc.severity_category,
                "distance_m": round(dist, 1),
                "incident_date": inc.incident_date.isoformat() if inc.incident_date else None,
                "time_window": inc.incident_time_window,
                "verification_status": inc.verification_status,
                "impact_score": round(impact, 2),
                "is_synthetic": inc.is_synthetic
            })

    # Infrastructure modifier
    infra_penalty = 0.0
    if segment.get("street_lighting_status") == "poor":
        infra_penalty += 15.0
    elif segment.get("street_lighting_status") == "adequate":
        infra_penalty -= 10.0

    if segment.get("police_facility_nearby"):
        infra_penalty -= 15.0
    if segment.get("transit_station_nearby"):
        infra_penalty -= 5.0  # Public transit usually has CCTV and foot traffic

    raw_segment_score = (exposure_sum * 12.0) + infra_penalty
    normalized_segment_score = max(0.0, min(100.0, raw_segment_score))

    metrics = {
        "exposure_sum": exposure_sum,
        "recency_sum": recency_sum,
        "incident_count": len(associated_incidents)
    }

    return normalized_segment_score, associated_incidents, metrics


def evaluate_route_risk(
    segments: List[Dict[str, Any]],
    all_incidents: List[Incident],
    departure_time_str: str = "18:00",
    departure_day: str = "Friday"
) -> Dict[str, Any]:
    """
    Evaluates total composite explainable risk score for a candidate route.
    Weights: Exposure (40%), Recency (20%), Infrastructure (15%), Time-of-Day (15%), Uncertainty (10%).
    """
    try:
        dep_hour = int(departure_time_str.split(":")[0])
    except Exception:
        dep_hour = 18

    total_exposure = 0.0
    total_recency = 0.0
    total_incidents_associated = 0
    unique_incident_ids = set()
    evaluated_segments = []

    for seg in segments:
        seg_score, nearby, metrics = calculate_segment_risk(
            segment=seg,
            all_incidents=all_incidents,
            departure_hour=dep_hour,
            buffer_radius_m=settings.INCIDENT_BUFFER_RADIUS_METERS,
            half_life_days=settings.RECENCY_HALF_LIFE_DAYS
        )
        seg_copy = dict(seg)
        seg_copy["segment_risk_score"] = round(seg_score, 1)
        seg_copy["nearby_incident_count"] = len(nearby)
        seg_copy["nearby_incidents"] = nearby
        evaluated_segments.append(seg_copy)

        total_exposure += metrics["exposure_sum"]
        total_recency += metrics["recency_sum"]
        for inc_dict in nearby:
            unique_incident_ids.add(inc_dict["internal_id"])

    num_segs = max(1, len(segments))
    avg_exposure_per_km = (total_exposure / (num_segs * (settings.SEGMENT_LENGTH_METERS / 1000.0))) if num_segs > 0 else 0.0

    # 1. Crime Exposure Score [0, 100] (normalized using logistic transformation)
    crime_exposure_score = min(100.0, (avg_exposure_per_km * 25.0))

    # 2. Recency Score [0, 100]
    recency_score = min(100.0, (total_recency / max(1, len(unique_incident_ids))) * 70.0) if unique_incident_ids else 10.0

    # 3. Contextual Infrastructure Score [0, 100]
    poor_lighting_count = sum(1 for s in segments if s.get("street_lighting_status") == "poor")
    police_count = sum(1 for s in segments if s.get("police_facility_nearby"))
    transit_count = sum(1 for s in segments if s.get("transit_station_nearby"))
    infra_raw = 50.0 + (poor_lighting_count / num_segs * 40.0) - (police_count / num_segs * 30.0) - (transit_count / num_segs * 15.0)
    infrastructure_score = max(5.0, min(95.0, infra_raw))

    # 4. Time-of-Day Score [0, 100]
    dep_window = get_time_window_from_hour(dep_hour)
    if dep_window in ["night", "late_night"]:
        temporal_score = 65.0 + min(30.0, len(unique_incident_ids) * 3.0)
    elif dep_window in ["early_morning", "evening"]:
        temporal_score = 45.0
    else:
        temporal_score = 30.0

    # 5. Data Uncertainty & Coverage Score [0, 100]
    # If fewer than 3 incidents in the area, data uncertainty is elevated
    if len(all_incidents) == 0:
        uncertainty_score = 90.0
        confidence_level = "Insufficient Data"
    elif len(unique_incident_ids) < 3:
        uncertainty_score = 60.0
        confidence_level = "Low"
    elif len(unique_incident_ids) < 10:
        uncertainty_score = 35.0
        confidence_level = "Moderate"
    else:
        uncertainty_score = 15.0
        confidence_level = "High"

    # Composite Score using Configured Weights
    w_exp = settings.WEIGHT_CRIME_EXPOSURE
    w_rec = settings.WEIGHT_INCIDENT_RECENCY
    w_inf = settings.WEIGHT_CONTEXTUAL_INFRASTRUCTURE
    w_tod = settings.WEIGHT_TIME_OF_DAY
    w_unc = settings.WEIGHT_DATA_UNCERTAINTY

    overall_score = (
        crime_exposure_score * w_exp +
        recency_score * w_rec +
        infrastructure_score * w_inf +
        temporal_score * w_tod +
        uncertainty_score * w_unc
    )
    overall_score = round(max(0.0, min(100.0, overall_score)), 1)

    # Human-Readable Explanations
    explanations = []
    if crime_exposure_score > 60:
        explanations.append(f"Elevated crime exposure ({len(unique_incident_ids)} relevant incidents documented within 250m of corridor).")
    else:
        explanations.append(f"Low to moderate historical incident density ({len(unique_incident_ids)} recorded incidents along corridor).")

    if dep_window in ["night", "late_night"]:
        explanations.append(f"Departure at {departure_time_str} ({dep_window.replace('_', ' ')}) correlates with increased vulnerability window.")
    else:
        explanations.append(f"Departure at {departure_time_str} is within daytime traffic hours.")

    if police_count > 0:
        explanations.append(f"Proximity to {police_count} verified Delhi Police facility zone(s) buffers risk.")

    caveats = [
        "Comparative analytical estimate only; not a guarantee of safety or prediction of future crime.",
        "Missing reports in public registries do not prove absence of crime in unmonitored sectors.",
        "Analysis based on publicly available news, police bulletins, and public disclosures."
    ]

    return {
        "overall_risk_score": overall_score,
        "crime_exposure_score": round(crime_exposure_score, 1),
        "recency_score": round(recency_score, 1),
        "infrastructure_score": round(infrastructure_score, 1),
        "temporal_score": round(temporal_score, 1),
        "uncertainty_score": round(uncertainty_score, 1),
        "incident_count": len(unique_incident_ids),
        "confidence_level": confidence_level,
        "score_breakdown": {
            "crime_exposure": round(crime_exposure_score, 1),
            "incident_recency": round(recency_score, 1),
            "contextual_infrastructure": round(infrastructure_score, 1),
            "time_of_day": round(temporal_score, 1),
            "data_uncertainty": round(uncertainty_score, 1),
            "weights": {
                "crime_exposure": w_exp,
                "incident_recency": w_rec,
                "contextual_infrastructure": w_inf,
                "time_of_day": w_tod,
                "data_uncertainty": w_unc
            },
            "explanations": explanations
        },
        "caveats": caveats,
        "segments": evaluated_segments
    }
