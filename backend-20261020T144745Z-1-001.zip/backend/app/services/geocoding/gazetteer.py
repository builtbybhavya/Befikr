import re
from typing import Dict, Any, Optional, List, Tuple
import math

# Authoritative Gazetteer of NCT of Delhi
# Includes Localities, Police Districts, Administrative Districts, and Key Transit/Police Hubs
DELHI_GAZETTEER: Dict[str, Dict[str, Any]] = {
    "connaught place": {
        "name": "Connaught Place",
        "district": "New Delhi",
        "police_district": "New Delhi",
        "lat": 28.6315,
        "lon": 77.2167,
        "precision": "street_level",
        "aliases": ["cp", "rajiv chowk", "inner circle", "outer circle", "barakhamba", "kasturba gandhi marg"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "rohini sector 10": {
        "name": "Rohini Sector 10",
        "district": "North West Delhi",
        "police_district": "Rohini",
        "lat": 28.7118,
        "lon": 77.1154,
        "precision": "street_level",
        "aliases": ["rohini sec 10", "rohini sector-10", "rohini west metro"],
        "infrastructure": {"lighting": "moderate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "rohini": {
        "name": "Rohini",
        "district": "North West Delhi",
        "police_district": "Rohini",
        "lat": 28.7159,
        "lon": 77.1147,
        "precision": "locality_level",
        "aliases": ["rohini subcity", "sector 3 rohini", "sector 7 rohini", "sector 8 rohini"],
        "infrastructure": {"lighting": "moderate", "road_type": "arterial", "commercial": "moderate", "transit_station": True, "police_station": True}
    },
    "pitampura": {
        "name": "Pitampura",
        "district": "North West Delhi",
        "police_district": "North West",
        "lat": 28.6990,
        "lon": 77.1384,
        "precision": "locality_level",
        "aliases": ["netaji subhash place", "nsp", "rani bagh", "kohat enclave"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "dwarka": {
        "name": "Dwarka",
        "district": "South West Delhi",
        "police_district": "Dwarka",
        "lat": 28.5921,
        "lon": 77.0460,
        "precision": "locality_level",
        "aliases": ["dwarka subcity", "dwarka sector 6", "dwarka sector 10", "dwarka sector 12", "dwarka sector 21"],
        "infrastructure": {"lighting": "moderate", "road_type": "arterial", "commercial": "moderate", "transit_station": True, "police_station": True}
    },
    "janakpuri": {
        "name": "Janakpuri",
        "district": "West Delhi",
        "police_district": "West",
        "lat": 28.6219,
        "lon": 77.0878,
        "precision": "locality_level",
        "aliases": ["janakpuri west", "janakpuri district centre", "tilak nagar border"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "karol bagh": {
        "name": "Karol Bagh",
        "district": "Central Delhi",
        "police_district": "Central",
        "lat": 28.6517,
        "lon": 77.1906,
        "precision": "street_level",
        "aliases": ["pusa road", "arya samaj road", "gaffar market", "ajmal khan road"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "chandni chowk": {
        "name": "Chandni Chowk",
        "district": "North Delhi",
        "police_district": "North",
        "lat": 28.6506,
        "lon": 77.2303,
        "precision": "street_level",
        "aliases": ["old delhi", "red fort area", "fatehpuri", "khari baoli", "jama masjid area"],
        "infrastructure": {"lighting": "adequate", "road_type": "collector", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "lajpat nagar": {
        "name": "Lajpat Nagar",
        "district": "South East Delhi",
        "police_district": "South East",
        "lat": 28.5677,
        "lon": 77.2433,
        "precision": "street_level",
        "aliases": ["central market lajpat nagar", "lajpat nagar ii", "lajpat nagar 4", "firoz gandhi road"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "saket": {
        "name": "Saket",
        "district": "South Delhi",
        "police_district": "South",
        "lat": 28.5244,
        "lon": 77.2100,
        "precision": "street_level",
        "aliases": ["select citywalk", "saket district centre", "press enclave", "max hospital saket"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "vasant kunj": {
        "name": "Vasant Kunj",
        "district": "South West Delhi",
        "police_district": "South West",
        "lat": 28.5293,
        "lon": 77.1554,
        "precision": "locality_level",
        "aliases": ["vasant kunj sector a", "vasant kunj sector b", "ambience mall vasant kunj", "jnu area"],
        "infrastructure": {"lighting": "moderate", "road_type": "arterial", "commercial": "moderate", "transit_station": False, "police_station": True}
    },
    "hauz khas": {
        "name": "Hauz Khas",
        "district": "South Delhi",
        "police_district": "South",
        "lat": 28.5494,
        "lon": 77.2001,
        "precision": "street_level",
        "aliases": ["hauz khas village", "hkv", "iit flyover area", "aurobindo marg"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "shahdara": {
        "name": "Shahdara",
        "district": "Shahdara",
        "police_district": "Shahdara",
        "lat": 28.6738,
        "lon": 77.2882,
        "precision": "locality_level",
        "aliases": ["shahdara metro", "grand trunk road shahdara", "chhota bazaar shahdara"],
        "infrastructure": {"lighting": "moderate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "preet vihar": {
        "name": "Preet Vihar",
        "district": "East Delhi",
        "police_district": "East",
        "lat": 28.6387,
        "lon": 77.2965,
        "precision": "locality_level",
        "aliases": ["vikas marg preet vihar", "swasthya vihar", "madhuban chowk east"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "moderate", "transit_station": True, "police_station": True}
    },
    "mayur vihar": {
        "name": "Mayur Vihar",
        "district": "East Delhi",
        "police_district": "East",
        "lat": 28.6080,
        "lon": 77.2980,
        "precision": "locality_level",
        "aliases": ["mayur vihar phase 1", "mayur vihar phase 2", "mayur vihar phase 3", "chilla regulator"],
        "infrastructure": {"lighting": "moderate", "road_type": "arterial", "commercial": "moderate", "transit_station": True, "police_station": True}
    },
    "kashmere gate": {
        "name": "Kashmere Gate",
        "district": "North Delhi",
        "police_district": "North",
        "lat": 28.6675,
        "lon": 77.2335,
        "precision": "street_level",
        "aliases": ["isbt kashmere gate", "st james church", "moris gate", "ring road kashmere gate"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "civil lines": {
        "name": "Civil Lines",
        "district": "North Delhi",
        "police_district": "North",
        "lat": 28.6814,
        "lon": 77.2228,
        "precision": "locality_level",
        "aliases": ["delhi university north campus", "alipur road civil lines", "rajpur road"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "moderate", "transit_station": True, "police_station": True}
    },
    "okhla": {
        "name": "Okhla",
        "district": "South East Delhi",
        "police_district": "South East",
        "lat": 28.5355,
        "lon": 77.2732,
        "precision": "locality_level",
        "aliases": ["okhla industrial area", "okhla phase 1", "okhla phase 2", "okhla phase 3", "jamia nagar"],
        "infrastructure": {"lighting": "moderate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "model town": {
        "name": "Model Town",
        "district": "North Delhi",
        "police_district": "North West",
        "lat": 28.7028,
        "lon": 77.1932,
        "precision": "locality_level",
        "aliases": ["model town 1", "model town 2", "model town 3", "derawal nagar"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "moderate", "transit_station": True, "police_station": True}
    },
    "paschim vihar": {
        "name": "Paschim Vihar",
        "district": "West Delhi",
        "police_district": "West",
        "lat": 28.6692,
        "lon": 77.1030,
        "precision": "locality_level",
        "aliases": ["jwala heri market", "paschim vihar east", "paschim vihar west", "peeragarhi chowk"],
        "infrastructure": {"lighting": "moderate", "road_type": "arterial", "commercial": "moderate", "transit_station": True, "police_station": True}
    },
    "punjabi bagh": {
        "name": "Punjabi Bagh",
        "district": "West Delhi",
        "police_district": "West",
        "lat": 28.6657,
        "lon": 77.1328,
        "precision": "locality_level",
        "aliases": ["punjabi bagh club", "punjabi bagh west", "punjabi bagh round about"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "rajouri garden": {
        "name": "Rajouri Garden",
        "district": "West Delhi",
        "police_district": "West",
        "lat": 28.6492,
        "lon": 77.1226,
        "precision": "street_level",
        "aliases": ["rajouri main market", "ring road rajouri garden", "city square mall rajouri"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "nehru place": {
        "name": "Nehru Place",
        "district": "South East Delhi",
        "police_district": "South East",
        "lat": 28.5492,
        "lon": 77.2530,
        "precision": "street_level",
        "aliases": ["nehru place market", "paras cinema flyover", "eros hotel area"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "narela": {
        "name": "Narela",
        "district": "North Delhi",
        "police_district": "Outer North",
        "lat": 28.8530,
        "lon": 77.0934,
        "precision": "locality_level",
        "aliases": ["narela industrial area", "narela mandi", "dsiidc narela"],
        "infrastructure": {"lighting": "poor", "road_type": "arterial", "commercial": "moderate", "transit_station": False, "police_station": True}
    },
    "bawana": {
        "name": "Bawana",
        "district": "North West Delhi",
        "police_district": "Outer North",
        "lat": 28.7981,
        "lon": 77.0322,
        "precision": "locality_level",
        "aliases": ["bawana industrial area", "bawana canal", "sector 1 bawana"],
        "infrastructure": {"lighting": "poor", "road_type": "arterial", "commercial": "moderate", "transit_station": False, "police_station": True}
    },
    "seelampur": {
        "name": "Seelampur",
        "district": "North East Delhi",
        "police_district": "North East",
        "lat": 28.6698,
        "lon": 77.2673,
        "precision": "locality_level",
        "aliases": ["seelampur chowk", "jafrabad road", "dharampura"],
        "infrastructure": {"lighting": "moderate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "najafgarh": {
        "name": "Najafgarh",
        "district": "South West Delhi",
        "police_district": "Dwarka",
        "lat": 28.6092,
        "lon": 76.9798,
        "precision": "locality_level",
        "aliases": ["najafgarh bazaar", "dhansa stand", "najafgarh road"],
        "infrastructure": {"lighting": "moderate", "road_type": "arterial", "commercial": "moderate", "transit_station": True, "police_station": True}
    },
    "delhi airport t3": {
        "name": "Indira Gandhi International Airport T3",
        "district": "South West Delhi",
        "police_district": "IGI Airport",
        "lat": 28.5562,
        "lon": 77.0999,
        "precision": "exact",
        "aliases": ["igi airport", "t3 terminal", "aerocity", "terminal 3"],
        "infrastructure": {"lighting": "adequate", "road_type": "highway", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "anand vihar": {
        "name": "Anand Vihar",
        "district": "East Delhi",
        "police_district": "Shahdara",
        "lat": 28.6469,
        "lon": 77.3160,
        "precision": "street_level",
        "aliases": ["isbt anand vihar", "anand vihar railway station", "kaushambi border"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "saket court": {
        "name": "Saket District Court",
        "district": "South Delhi",
        "police_district": "South",
        "lat": 28.5204,
        "lon": 77.2148,
        "precision": "exact",
        "aliases": ["saket court complex", "saket judicial academy"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    },
    "delhi university north campus": {
        "name": "Delhi University North Campus",
        "district": "North Delhi",
        "police_district": "North",
        "lat": 28.6890,
        "lon": 77.2104,
        "precision": "locality_level",
        "aliases": ["du north campus", "vishwavidyalaya", "kamla nagar", "mall road du", "chhatra marg"],
        "infrastructure": {"lighting": "adequate", "road_type": "arterial", "commercial": "high", "transit_station": True, "police_station": True}
    }
}


def geocode_delhi_text(text: str) -> Optional[Dict[str, Any]]:
    """
    Geocodes text against the Delhi gazetteer using fuzzy alias matching.
    Returns matched locality info or None.
    """
    if not text:
        return None
    cleaned = text.lower().strip()
    cleaned = re.sub(r'[,.\-_/]', ' ', cleaned)
    tokens = set(cleaned.split())

    # 1. Exact match on gazetteer keys
    for key, data in DELHI_GAZETTEER.items():
        if key in cleaned:
            return data

    # 2. Match on aliases
    for key, data in DELHI_GAZETTEER.items():
        for alias in data.get("aliases", []):
            if alias in cleaned:
                return data

    # 3. Token containment match
    for key, data in DELHI_GAZETTEER.items():
        key_tokens = set(key.split())
        if key_tokens.issubset(tokens):
            return data

    return None


def haversine_distance_meters(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Computes great-circle distance between two GPS coordinates in meters.
    """
    R = 6371000.0  # Earth's radius in meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = math.sin(delta_phi / 2.0) ** 2 + \
        math.cos(phi1) * math.cos(phi2) * \
        math.sin(delta_lambda / 2.0) ** 2
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
    return R * c
