from typing import Dict, Any, List
from sqlalchemy.orm import Session
from sqlalchemy import func
from backend.app.models.models import Incident, Source, SourceDocument, GeographicArea


def get_analytics_overview(db: Session) -> Dict[str, Any]:
    """Generates top-level crime intelligence analytics overview."""
    total_sources = db.query(Source).count()
    total_docs = db.query(SourceDocument).count()
    total_incidents = db.query(Incident).count()
    verified_count = db.query(Incident).filter(Incident.verification_status == "verified").count()
    unverified_count = db.query(Incident).filter(Incident.verification_status == "unverified").count()
    synthetic_count = db.query(Incident).filter(Incident.is_synthetic == True).count()
    live_count = db.query(Incident).filter(Incident.is_synthetic == False).count()

    # Category breakdown
    cat_rows = db.query(Incident.crime_category, func.count(Incident.id)).group_by(Incident.crime_category).all()
    category_distribution = {cat: count for cat, count in cat_rows}

    # Severity breakdown
    sev_rows = db.query(Incident.severity_category, func.count(Incident.id)).group_by(Incident.severity_category).all()
    severity_distribution = {sev: count for sev, count in sev_rows}

    # District breakdown
    dist_rows = db.query(Incident.district, func.count(Incident.id)).group_by(Incident.district).all()
    district_distribution = {dist or "Unassigned": count for dist, count in dist_rows}

    # Coverage estimation
    delhi_districts_total = 11
    districts_with_data = len([d for d in district_distribution if d != "Unassigned"])
    coverage_pct = round((districts_with_data / max(1, delhi_districts_total)) * 100.0, 1)

    latest_incident = db.query(Incident).order_by(Incident.created_at.desc()).first()

    return {
        "total_sources": total_sources,
        "total_documents": total_docs,
        "total_incidents": total_incidents,
        "verified_incidents": verified_count,
        "unverified_incidents": unverified_count,
        "synthetic_incidents": synthetic_count,
        "live_incidents": live_count,
        "last_update": latest_incident.created_at if latest_incident else None,
        "data_coverage_percentage": coverage_pct,
        "category_distribution": category_distribution,
        "severity_distribution": severity_distribution,
        "district_distribution": district_distribution
    }


def get_timeline_analytics(db: Session) -> List[Dict[str, Any]]:
    """Groups incidents by month for historical timeline visualizations."""
    incidents = db.query(Incident).order_by(Incident.incident_date.asc()).all()
    timeline = {}
    for inc in incidents:
        dt = inc.incident_date or inc.publication_date
        if not dt:
            continue
        key = dt.strftime("%Y-%m")
        if key not in timeline:
            timeline[key] = {"date": key, "count": 0, "categories": {}}
        timeline[key]["count"] += 1
        cat = inc.crime_category
        timeline[key]["categories"][cat] = timeline[key]["categories"].get(cat, 0) + 1

    return list(timeline.values())
