from typing import List
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

    APP_NAME: str = "NIRIKSHAK"
    APP_TAGLINE: str = "Understand the evidence. Visualize the risk. Choose your route."
    APP_VERSION: str = "1.0.0"
    APP_ENV: str = "development"
    DEMO_MODE: bool = True

    # Database
    DATABASE_URL: str = "sqlite:///./nirikshak.db"

    # Google Maps Platform (Optional)
    GOOGLE_MAPS_API_KEY: str = ""
    GOOGLE_PLACES_API_KEY: str = ""
    GOOGLE_ROUTES_API_KEY: str = ""
    GOOGLE_STREET_VIEW_API_KEY: str = ""

    # LLM / Extraction Engine
    LLM_PROVIDER: str = "mock"  # 'mock', 'openai', 'anthropic', 'gemini'
    LLM_API_KEY: str = ""
    LLM_MODEL: str = ""

    # Routing Provider
    OSRM_ROUTER_URL: str = "https://router.project-osrm.org"

    # Scoring Engine Weights (Total = 1.0)
    WEIGHT_CRIME_EXPOSURE: float = 0.40
    WEIGHT_INCIDENT_RECENCY: float = 0.20
    WEIGHT_CONTEXTUAL_INFRASTRUCTURE: float = 0.15
    WEIGHT_TIME_OF_DAY: float = 0.15
    WEIGHT_DATA_UNCERTAINTY: float = 0.10

    # Geospatial Parameters
    SEGMENT_LENGTH_METERS: int = 150
    INCIDENT_BUFFER_RADIUS_METERS: int = 250
    RECENCY_HALF_LIFE_DAYS: int = 180

    # Server Settings
    BACKEND_HOST: str = "127.0.0.1"
    BACKEND_PORT: int = 8000
    FRONTEND_PORT: int = 5173
    CORS_ORIGINS: str = "http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000"

    @property
    def cors_origin_list(self) -> List[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


settings = Settings()
