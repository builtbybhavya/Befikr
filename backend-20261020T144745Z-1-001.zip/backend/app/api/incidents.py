import json
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import or_
from backend.app.db.session import get_db
from backend.app.models.models import Incident, VerificationEvent
from backend.app.schemas.schemas import (
    IncidentResponse,
    IncidentListResponse,
    IncidentVerifyRequest,
    IncidentCorrectRequest
)

router = APIRouter(prefix="/incidents", tags=["Incidents"])


@router.get("", response_model=IncidentListResponse)
def list_incidents(
    category: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    verification_status: Optional[str] = Query(None),
    locality: Optional[str] = Query(None),
    is_synthetic: Optional[bool] = Query(None),
    search: Optional[str] = Query(None),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db)
):
    """Retrieves paginated and filtered crime incidents across NCT of Delhi."""
    query = db.query(Incident)

    if category:
        query = query.filter(Incident.crime_category == category)
    if severity:
        query = query.filter(Incident.severity_category == severity)
    if verification_status:
        query = query.filter(Incident.verification_status == verification_status)
    if locality:
        query = query.filter(Incident.locality.ilike(f"%{locality}%"))
    if is_synthetic is not None:
        query = query.filter(Incident.is_synthetic == is_synthetic)
    if search:
        search_filter = or_(
            Incident.original_title.ilike(f"%{search}%"),
            Incident.description.ilike(f"%{search}%"),
            Incident.named_location.ilike(f"%{search}%"),
            Incident.internal_id.ilike(f"%{search}%")
        )
        query = query.filter(search_filter)

    total = query.count()
    incidents = query.order_by(Incident.incident_date.desc().nullslast()).offset(offset).limit(limit).all()

    return IncidentListResponse(
        total=total,
        incidents=[IncidentResponse.model_validate(inc) for inc in incidents],
        offset=offset,
        limit=limit
    )


@router.get("/{incident_id}", response_model=IncidentResponse)
def get_incident_detail(incident_id: str, db: Session = Depends(get_db)):
    """Retrieves full details, evidence snippet, and provenance of a specific incident."""
    inc = db.query(Incident).filter(
        or_(Incident.internal_id == incident_id, Incident.id == int(incident_id) if incident_id.isdigit() else False)
    ).first()

    if not inc:
        raise HTTPException(status_code=404, detail="Incident not found")

    return IncidentResponse.model_validate(inc)


@router.post("/{incident_id}/verify")
def verify_incident(
    incident_id: str,
    payload: IncidentVerifyRequest,
    db: Session = Depends(get_db)
):
    """
    Review queue action: marks an incident as verified, disputed, or rejected
    with human-in-the-loop analyst audit trail.
    """
    inc = db.query(Incident).filter(
        or_(Incident.internal_id == incident_id, Incident.id == int(incident_id) if incident_id.isdigit() else False)
    ).first()

    if not inc:
        raise HTTPException(status_code=404, detail="Incident not found")

    old_status = inc.verification_status
    inc.verification_status = payload.status

    # Record verification event audit log
    event = VerificationEvent(
        incident_id=inc.id,
        action=payload.status,
        performed_by=payload.performed_by,
        notes=payload.notes,
        previous_data=json.dumps({"verification_status": old_status}),
        new_data=json.dumps({"verification_status": payload.status})
    )
    db.add(event)
    db.commit()

    return {
        "status": "success",
        "incident_id": inc.internal_id,
        "verification_status": inc.verification_status,
        "performed_by": payload.performed_by
    }


@router.post("/{incident_id}/correct")
def correct_incident(
    incident_id: str,
    payload: IncidentCorrectRequest,
    db: Session = Depends(get_db)
):
    """
    Corrects incident attributes (category, location, coordinates)
    while recording previous values in the verification audit history.
    """
    inc = db.query(Incident).filter(
        or_(Incident.internal_id == incident_id, Incident.id == int(incident_id) if incident_id.isdigit() else False)
    ).first()

    if not inc:
        raise HTTPException(status_code=404, detail="Incident not found")

    prev_state = {
        "crime_category": inc.crime_category,
        "severity_category": inc.severity_category,
        "locality": inc.locality,
        "latitude": inc.latitude,
        "longitude": inc.longitude
    }

    if payload.crime_category:
        inc.crime_category = payload.crime_category
    if payload.severity_category:
        inc.severity_category = payload.severity_category
    if payload.locality:
        inc.locality = payload.locality
        inc.named_location = payload.locality
    if payload.latitude is not None and payload.longitude is not None:
        inc.latitude = payload.latitude
        inc.longitude = payload.longitude
    if payload.geographic_precision:
        inc.geographic_precision = payload.geographic_precision

    inc.verification_status = "verified"

    new_state = {
        "crime_category": inc.crime_category,
        "severity_category": inc.severity_category,
        "locality": inc.locality,
        "latitude": inc.latitude,
        "longitude": inc.longitude
    }

    event = VerificationEvent(
        incident_id=inc.id,
        action="corrected",
        performed_by=payload.performed_by,
        notes=payload.notes or "Attribute correction submitted",
        previous_data=json.dumps(prev_state),
        new_data=json.dumps(new_state)
    )
    db.add(event)
    db.commit()

    return {
        "status": "success",
        "incident_id": inc.internal_id,
        "updated_record": IncidentResponse.model_validate(inc)
    }
