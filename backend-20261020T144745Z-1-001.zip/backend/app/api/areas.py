from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from backend.app.db.session import get_db
from backend.app.models.models import GeographicArea, Incident
from backend.app.schemas.schemas import GeographicAreaResponse

router = APIRouter(prefix="/areas", tags=["Geographic Areas"])


@router.get("", response_model=List[GeographicAreaResponse])
def list_geographic_areas(db: Session = Depends(get_db)):
    """Retrieves Delhi localities and districts with risk indicators and incident tallies."""
    areas = db.query(GeographicArea).all()
    for area in areas:
        cnt = db.query(Incident).filter(Incident.locality.ilike(f"%{area.name}%")).count()
        area.incident_count = cnt
    return [GeographicAreaResponse.model_validate(a) for a in areas]
