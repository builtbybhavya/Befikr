import json
import uuid
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.app.db.session import get_db
from backend.app.models.models import Incident, RouteAnalysis, RouteAlternative, RouteSegment
from backend.app.schemas.schemas import (
    RouteRequest,
    RouteAnalysisResponse,
    RouteAlternativeResponse,
    RouteSegmentResponse
)
from backend.app.services.routing.router import get_route_alternatives, build_route_segments
from backend.app.services.risk.engine import evaluate_route_risk

router = APIRouter(prefix="/routes", tags=["Routes & Risk Analysis"])


@router.post("/analyze", response_model=RouteAnalysisResponse)
async def analyze_routes(payload: RouteRequest, db: Session = Depends(get_db)):
    """
    Computes candidate routes between origin and destination in NCT of Delhi,
    divides routes into 150m segments, correlates historical & live crime records,
    and calculates transparent comparative risk scores.
    """
    origin = (payload.origin.lat, payload.origin.lon)
    destination = (payload.destination.lat, payload.destination.lon)

    # 1. Fetch alternative routes (OSRM or Delhi Hub Router)
    raw_routes = await get_route_alternatives(
        origin=origin,
        destination=destination,
        travel_mode=payload.travel_mode,
        use_osrm=payload.use_osrm
    )

    if not raw_routes:
        raise HTTPException(status_code=400, detail="Unable to calculate routes between requested locations")

    # 2. Fetch all incidents from database for spatial correlation
    all_incidents = db.query(Incident).all()

    # 3. Create RouteAnalysis database entity
    analysis = RouteAnalysis(
        id=str(uuid.uuid4()),
        origin_name=payload.origin.name or f"Origin ({round(payload.origin.lat, 4)}, {round(payload.origin.lon, 4)})",
        origin_lat=payload.origin.lat,
        origin_lon=payload.origin.lon,
        destination_name=payload.destination.name or f"Destination ({round(payload.destination.lat, 4)}, {round(payload.destination.lon, 4)})",
        destination_lat=payload.destination.lat,
        destination_lon=payload.destination.lon,
        travel_mode=payload.travel_mode,
        departure_time=payload.departure_time,
        departure_day=payload.departure_day
    )
    db.add(analysis)

    evaluated_alternatives = []

    for idx, r in enumerate(raw_routes):
        coords = r["coordinates"]
        segments = build_route_segments(coords, target_segment_length_m=150.0)

        # Evaluate Explainable Risk Score
        risk_result = evaluate_route_risk(
            segments=segments,
            all_incidents=all_incidents,
            departure_time_str=payload.departure_time,
            departure_day=payload.departure_day
        )

        geojson_geom = {
            "type": "LineString",
            "coordinates": [[c[1], c[0]] for c in coords]  # GeoJSON is [lon, lat]
        }

        alt_id = str(uuid.uuid4())
        alt_db = RouteAlternative(
            id=alt_id,
            analysis_id=analysis.id,
            alternative_index=idx,
            provider=r.get("provider", "osrm"),
            route_name=r.get("route_name", f"Alternative {idx + 1}"),
            total_distance_m=r["distance_m"],
            total_duration_s=r["duration_s"],
            overall_risk_score=risk_result["overall_risk_score"],
            crime_exposure_score=risk_result["crime_exposure_score"],
            recency_score=risk_result["recency_score"],
            infrastructure_score=risk_result["infrastructure_score"],
            temporal_score=risk_result["temporal_score"],
            uncertainty_score=risk_result["uncertainty_score"],
            incident_count=risk_result["incident_count"],
            confidence_level=risk_result["confidence_level"],
            score_breakdown=json.dumps(risk_result["score_breakdown"]),
            caveats=json.dumps(risk_result["caveats"]),
            geometry_geojson=json.dumps(geojson_geom)
        )
        db.add(alt_db)

        # Save segments
        db_segments = []
        for s in risk_result["segments"]:
            seg_entity = RouteSegment(
                alternative_id=alt_id,
                segment_index=s["segment_index"],
                start_lat=s["start_lat"],
                start_lon=s["start_lon"],
                end_lat=s["end_lat"],
                end_lon=s["end_lon"],
                distance_m=s["distance_m"],
                duration_s=s["duration_s"],
                segment_risk_score=s["segment_risk_score"],
                nearby_incident_count=s["nearby_incident_count"],
                street_lighting_status=s["street_lighting_status"],
                road_type=s["road_type"],
                commercial_activity=s["commercial_activity"],
                police_facility_nearby=s["police_facility_nearby"],
                transit_station_nearby=s["transit_station_nearby"],
                geometry_geojson=json.dumps(s["geometry_geojson"])
            )
            db.add(seg_entity)
            db_segments.append(RouteSegmentResponse(
                segment_index=s["segment_index"],
                start_lat=s["start_lat"],
                start_lon=s["start_lon"],
                end_lat=s["end_lat"],
                end_lon=s["end_lon"],
                distance_m=s["distance_m"],
                duration_s=s["duration_s"],
                segment_risk_score=s["segment_risk_score"],
                nearby_incident_count=s["nearby_incident_count"],
                street_lighting_status=s["street_lighting_status"],
                road_type=s["road_type"],
                commercial_activity=s["commercial_activity"],
                police_facility_nearby=s["police_facility_nearby"],
                transit_station_nearby=s["transit_station_nearby"],
                geometry_geojson=s["geometry_geojson"],
                nearby_incidents=s["nearby_incidents"]
            ))

        evaluated_alternatives.append(RouteAlternativeResponse(
            id=alt_id,
            alternative_index=idx,
            provider=r.get("provider", "osrm"),
            route_name=r.get("route_name", f"Alternative {idx + 1}"),
            total_distance_m=r["distance_m"],
            total_duration_s=r["duration_s"],
            overall_risk_score=risk_result["overall_risk_score"],
            crime_exposure_score=risk_result["crime_exposure_score"],
            recency_score=risk_result["recency_score"],
            infrastructure_score=risk_result["infrastructure_score"],
            temporal_score=risk_result["temporal_score"],
            uncertainty_score=risk_result["uncertainty_score"],
            incident_count=risk_result["incident_count"],
            confidence_level=risk_result["confidence_level"],
            score_breakdown=risk_result["score_breakdown"],
            caveats=risk_result["caveats"],
            geometry_geojson=geojson_geom,
            segments=db_segments
        ))

    # Generate comparative summary
    if len(evaluated_alternatives) > 1:
        best_alt = min(evaluated_alternatives, key=lambda a: a.overall_risk_score)
        other_alt = max(evaluated_alternatives, key=lambda a: a.overall_risk_score)
        score_diff = round(other_alt.overall_risk_score - best_alt.overall_risk_score, 1)
        analysis.comparison_summary = (
            f"'{best_alt.route_name}' has an estimated comparative risk score of {best_alt.overall_risk_score}/100 "
            f"({score_diff} points lower than '{other_alt.route_name}'), primarily due to "
            f"{'fewer corridor incident records' if best_alt.incident_count < other_alt.incident_count else 'superior infrastructure lighting & transit coverage'}."
        )
    else:
        analysis.comparison_summary = f"Evaluated single corridor with risk score {evaluated_alternatives[0].overall_risk_score}/100."

    db.commit()

    return RouteAnalysisResponse(
        id=analysis.id,
        origin_name=analysis.origin_name,
        origin_lat=analysis.origin_lat,
        origin_lon=analysis.origin_lon,
        destination_name=analysis.destination_name,
        destination_lat=analysis.destination_lat,
        destination_lon=analysis.destination_lon,
        travel_mode=analysis.travel_mode,
        departure_time=analysis.departure_time,
        departure_day=analysis.departure_day,
        created_at=analysis.created_at,
        comparison_summary=analysis.comparison_summary,
        alternatives=evaluated_alternatives
    )


@router.get("/{analysis_id}", response_model=RouteAnalysisResponse)
def get_route_analysis(analysis_id: str, db: Session = Depends(get_db)):
    """Retrieves previous route analysis and risk breakdown."""
    analysis = db.query(RouteAnalysis).filter(RouteAnalysis.id == analysis_id).first()
    if not analysis:
        raise HTTPException(status_code=404, detail="Route analysis not found")

    alts = db.query(RouteAlternative).filter(RouteAlternative.analysis_id == analysis.id).all()
    alt_responses = []

    for a in alts:
        segments = db.query(RouteSegment).filter(RouteSegment.alternative_id == a.id).order_by(RouteSegment.segment_index.asc()).all()
        seg_responses = []
        for s in segments:
            seg_responses.append(RouteSegmentResponse(
                segment_index=s.segment_index,
                start_lat=s.start_lat,
                start_lon=s.start_lon,
                end_lat=s.end_lat,
                end_lon=s.end_lon,
                distance_m=s.distance_m,
                duration_s=s.duration_s,
                segment_risk_score=s.segment_risk_score,
                nearby_incident_count=s.nearby_incident_count,
                street_lighting_status=s.street_lighting_status,
                road_type=s.road_type,
                commercial_activity=s.commercial_activity,
                police_facility_nearby=s.police_facility_nearby,
                transit_station_nearby=s.transit_station_nearby,
                geometry_geojson=json.loads(s.geometry_geojson)
            ))

        alt_responses.append(RouteAlternativeResponse(
            id=a.id,
            alternative_index=a.alternative_index,
            provider=a.provider,
            route_name=a.route_name,
            total_distance_m=a.total_distance_m,
            total_duration_s=a.total_duration_s,
            overall_risk_score=a.overall_risk_score,
            crime_exposure_score=a.crime_exposure_score,
            recency_score=a.recency_score,
            infrastructure_score=a.infrastructure_score,
            temporal_score=a.temporal_score,
            uncertainty_score=a.uncertainty_score,
            incident_count=a.incident_count,
            confidence_level=a.confidence_level,
            score_breakdown=json.loads(a.score_breakdown),
            caveats=json.loads(a.caveats),
            geometry_geojson=json.loads(a.geometry_geojson),
            segments=seg_responses
        ))

    return RouteAnalysisResponse(
        id=analysis.id,
        origin_name=analysis.origin_name,
        origin_lat=analysis.origin_lat,
        origin_lon=analysis.origin_lon,
        destination_name=analysis.destination_name,
        destination_lat=analysis.destination_lat,
        destination_lon=analysis.destination_lon,
        travel_mode=analysis.travel_mode,
        departure_time=analysis.departure_time,
        departure_day=analysis.departure_day,
        created_at=analysis.created_at,
        comparison_summary=analysis.comparison_summary or "",
        alternatives=alt_responses
    )
