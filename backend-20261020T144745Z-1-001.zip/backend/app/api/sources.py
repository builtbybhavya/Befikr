from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from backend.app.db.session import get_db
from backend.app.models.models import Source, SourceDocument, Incident
from backend.app.schemas.schemas import SourceResponse, SourceCreate
from backend.app.services.ingestion.feed_ingester import sync_source_feed

router = APIRouter(prefix="/sources", tags=["Sources"])


@router.get("", response_model=List[SourceResponse])
def list_sources(db: Session = Depends(get_db)):
    """Lists registered public sources, reliability scores, and status."""
    sources = db.query(Source).all()
    results = []
    for s in sources:
        doc_count = db.query(SourceDocument).filter(SourceDocument.source_id == s.id).count()
        inc_count = db.query(Incident).filter(Incident.source_id == s.id).count()
        results.append(SourceResponse(
            id=s.id,
            name=s.name,
            url=s.url,
            source_type=s.source_type,
            reliability_score=s.reliability_score,
            retrieval_method=s.retrieval_method,
            last_successful_retrieval=s.last_successful_retrieval,
            ingestion_status=s.ingestion_status,
            error_log=s.error_log,
            created_at=s.created_at,
            document_count=doc_count,
            incident_count=inc_count
        ))
    return results


@router.post("", response_model=SourceResponse, status_code=status.HTTP_201_CREATED)
def create_source(payload: SourceCreate, db: Session = Depends(get_db)):
    """Registers a new crime intelligence or news source."""
    new_source = Source(
        name=payload.name,
        url=payload.url,
        source_type=payload.source_type,
        reliability_score=payload.reliability_score,
        retrieval_method=payload.retrieval_method,
        ingestion_status="idle"
    )
    db.add(new_source)
    db.commit()
    db.refresh(new_source)
    return SourceResponse(
        id=new_source.id,
        name=new_source.name,
        url=new_source.url,
        source_type=new_source.source_type,
        reliability_score=new_source.reliability_score,
        retrieval_method=new_source.retrieval_method,
        last_successful_retrieval=new_source.last_successful_retrieval,
        ingestion_status=new_source.ingestion_status,
        error_log=new_source.error_log,
        created_at=new_source.created_at,
        document_count=0,
        incident_count=0
    )


@router.post("/{source_id}/sync")
async def trigger_source_sync(source_id: int, db: Session = Depends(get_db)):
    """Triggers ingestion for a registered source."""
    source = db.query(Source).filter(Source.id == source_id).first()
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")

    result = await sync_source_feed(source, db)
    return result
