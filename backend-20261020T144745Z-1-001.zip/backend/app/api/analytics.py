from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List, Dict, Any
from backend.app.db.session import get_db
from backend.app.services.analytics.service import get_analytics_overview, get_timeline_analytics
from backend.app.schemas.schemas import AnalyticsOverviewResponse, TimelinePoint

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("/overview", response_model=AnalyticsOverviewResponse)
def analytics_overview(db: Session = Depends(get_db)):
    """Summary metrics of crime incidents, sources, verification, and coverage."""
    return get_analytics_overview(db)


@router.get("/timeline", response_model=List[TimelinePoint])
def analytics_timeline(db: Session = Depends(get_db)):
    """Historical timeline of recorded Delhi incidents grouped by month and category."""
    return get_timeline_analytics(db)


@router.get("/coverage")
def analytics_coverage(db: Session = Depends(get_db)):
    """Diagnostic metrics of data completeness across Delhi administrative districts."""
    overview = get_analytics_overview(db)
    return {
        "coverage_percentage": overview["data_coverage_percentage"],
        "districts_covered": overview["district_distribution"],
        "unassigned_records": overview["district_distribution"].get("Unassigned", 0),
        "notes": "Low report volume in certain districts indicates reporting gaps rather than absence of crime."
    }
