from typing import Dict, Any, List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.app.db.session import get_db
from backend.app.models.models import ApplicationSetting
from backend.app.core.config import settings
from backend.app.schemas.schemas import SettingUpdate

router = APIRouter(prefix="/settings", tags=["Settings"])


@router.get("")
def get_all_settings(db: Session = Depends(get_db)):
    """Retrieves all application settings, scoring weights, and API status."""
    db_settings = db.query(ApplicationSetting).all()
    settings_dict = {s.key: {"value": s.value, "category": s.category, "description": s.description} for s in db_settings}

    # Also include runtime API diagnostics
    api_status = {
        "google_maps_configured": bool(settings.GOOGLE_MAPS_API_KEY),
        "osrm_router_active": True,
        "osrm_router_url": settings.OSRM_ROUTER_URL,
        "llm_provider": settings.LLM_PROVIDER,
        "demo_mode": settings.DEMO_MODE,
        "database_url": settings.DATABASE_URL.split("@")[-1] if "@" in settings.DATABASE_URL else settings.DATABASE_URL
    }

    return {
        "configuration": settings_dict,
        "api_status": api_status
    }


@router.patch("/{key}")
def update_setting(key: str, payload: SettingUpdate, db: Session = Depends(get_db)):
    """Updates a configuration setting (e.g. scoring weight)."""
    setting = db.query(ApplicationSetting).filter(ApplicationSetting.key == key).first()
    if not setting:
        setting = ApplicationSetting(key=key, value=payload.value, category=payload.category or "general", description=payload.description)
        db.add(setting)
    else:
        setting.value = payload.value
        if payload.description:
            setting.description = payload.description

    db.commit()
    db.refresh(setting)

    # If updating weights, update live settings object in memory as well
    try:
        val_f = float(payload.value)
        if key == "weight_crime_exposure":
            settings.WEIGHT_CRIME_EXPOSURE = val_f
        elif key == "weight_incident_recency":
            settings.WEIGHT_INCIDENT_RECENCY = val_f
        elif key == "weight_contextual_infrastructure":
            settings.WEIGHT_CONTEXTUAL_INFRASTRUCTURE = val_f
        elif key == "weight_time_of_day":
            settings.WEIGHT_TIME_OF_DAY = val_f
        elif key == "weight_data_uncertainty":
            settings.WEIGHT_DATA_UNCERTAINTY = val_f
    except ValueError:
        pass

    return {"status": "success", "key": setting.key, "value": setting.value}
