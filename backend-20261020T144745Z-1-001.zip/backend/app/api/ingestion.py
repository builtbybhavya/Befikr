import uuid
import datetime
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from sqlalchemy.orm import Session
from backend.app.db.session import get_db
from backend.app.models.models import Source, SourceDocument, Incident
from backend.app.services.ingestion.document_parser import parse_pdf_document, parse_csv_records, parse_json_records
from backend.app.services.extraction.extractor import extract_incident_from_text
from backend.app.services.extraction.deduplicator import find_duplicate_incident

router = APIRouter(prefix="/ingestion", tags=["Ingestion"])


@router.post("/upload")
async def upload_crime_report(
    file: UploadFile = File(...),
    publisher: str = Form("User Public Upload"),
    source_type: str = Form("user_upload"),
    db: Session = Depends(get_db)
):
    """
    Ingests and parses public crime reports in PDF, JSON, CSV, or Text format.
    Extracts structured incidents with geocoding, deduplication, and provenance tracking.
    """
    file_bytes = await file.read()
    filename = file.filename or "uploaded_report"
    ext = filename.split(".")[-1].lower() if "." in filename else ""

    # Find or create user upload source
    source = db.query(Source).filter(Source.source_type == "user_upload").first()
    if not source:
        source = Source(
            name="Public Report Uploads",
            url="local://user-uploads",
            source_type="user_upload",
            reliability_score=0.75,
            retrieval_method="upload",
            ingestion_status="idle"
        )
        db.add(source)
        db.commit()
        db.refresh(source)

    extracted_records = []
    text_content = ""

    if ext == "pdf":
        text_content = parse_pdf_document(file_bytes)
        # Split text into paragraphs or incident candidates
        paragraphs = [p for p in text_content.split("\n\n") if len(p.strip()) > 40]
        for p in paragraphs:
            inc = extract_incident_from_text(
                title=p[:80].strip(),
                text=p,
                pub_date=datetime.datetime.utcnow(),
                source_url=f"local://uploads/{filename}",
                publisher=publisher
            )
            if inc:
                extracted_records.append(inc)

    elif ext == "csv":
        rows = parse_csv_records(file_bytes)
        for r in rows:
            title = r.get("title") or r.get("description") or "Reported Incident"
            desc = r.get("description") or r.get("details") or title
            inc = extract_incident_from_text(
                title=title,
                text=desc,
                pub_date=datetime.datetime.utcnow(),
                source_url=f"local://uploads/{filename}",
                publisher=publisher
            )
            if inc:
                # If explicit coordinates in CSV, override
                if "latitude" in r and "longitude" in r:
                    try:
                        inc["latitude"] = float(r["latitude"])
                        inc["longitude"] = float(r["longitude"])
                        inc["geographic_precision"] = "exact"
                    except ValueError:
                        pass
                extracted_records.append(inc)

    elif ext == "json":
        items = parse_json_records(file_bytes)
        for item in items:
            title = item.get("title") or item.get("description") or "Reported Incident"
            desc = item.get("description") or title
            inc = extract_incident_from_text(
                title=title,
                text=desc,
                pub_date=datetime.datetime.utcnow(),
                source_url=f"local://uploads/{filename}",
                publisher=publisher
            )
            if inc:
                if "latitude" in item and "longitude" in item:
                    try:
                        inc["latitude"] = float(item["latitude"])
                        inc["longitude"] = float(item["longitude"])
                        inc["geographic_precision"] = "exact"
                    except (ValueError, TypeError):
                        pass
                extracted_records.append(inc)

    else:
        # Plain text
        text_content = file_bytes.decode("utf-8", errors="replace")
        paragraphs = [p for p in text_content.split("\n\n") if len(p.strip()) > 40]
        for p in paragraphs:
            inc = extract_incident_from_text(
                title=p[:80].strip(),
                text=p,
                pub_date=datetime.datetime.utcnow(),
                source_url=f"local://uploads/{filename}",
                publisher=publisher
            )
            if inc:
                extracted_records.append(inc)

    # Save document record
    doc = SourceDocument(
        source_id=source.id,
        title=filename,
        url=f"local://uploads/{filename}",
        content_raw=text_content[:5000] if text_content else f"File upload: {filename}",
        document_format=ext,
        publication_date=datetime.datetime.utcnow()
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)

    # Deduplicate and save
    existing_incidents = db.query(Incident).all()
    created_count = 0
    deduped_count = 0

    for item in extracted_records:
        dup = find_duplicate_incident(item, existing_incidents)
        if dup:
            dup.corroboration_count += 1
            deduped_count += 1
        else:
            inc_id = f"DL-UPL-{uuid.uuid4().hex[:8].upper()}"
            new_inc = Incident(
                internal_id=inc_id,
                source_id=source.id,
                source_document_id=doc.id,
                original_title=item["original_title"],
                original_url=item["original_url"],
                publisher=item["publisher"],
                publication_date=item["publication_date"],
                incident_date=item["incident_date"],
                incident_time_window=item["incident_time_window"],
                crime_category=item["crime_category"],
                severity_category=item["severity_category"],
                description=item["description"],
                named_location=item["named_location"],
                locality=item["locality"],
                police_district=item["police_district"],
                district=item["district"],
                latitude=item["latitude"],
                longitude=item["longitude"],
                geographic_precision=item["geographic_precision"],
                incident_status=item["incident_status"],
                corroboration_count=1,
                extraction_confidence=item["extraction_confidence"],
                geocoding_confidence=item["geocoding_confidence"],
                verification_status="unverified",
                is_synthetic=False,
                source_passage=item["source_passage"]
            )
            db.add(new_inc)
            existing_incidents.append(new_inc)
            created_count += 1

    db.commit()

    return {
        "status": "success",
        "filename": filename,
        "format": ext,
        "total_extracted": len(extracted_records),
        "new_incidents_created": created_count,
        "deduplicated": deduped_count
    }
